import React, { useState, useEffect, useRef } from 'react';
import { SectionProps } from '../types';

interface SlideData {
  title: string;
  subtitle?: string;
  content: React.ReactNode;
  icon: string;
}

export const TrainingModuleView: React.FC<SectionProps> = ({ onBack }) => {
  const [activeSlide, setActiveSlide] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (window.innerWidth < 768) {
        contentRef.current?.scrollIntoView({ behavior: 'smooth' });
    } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [activeSlide]);

  const slides: SlideData[] = [
    {
      title: "1. Fáza: Oh F#@& (Amygdala Hijack)",
      subtitle: "Biologický základ odporu",
      icon: "fa-bolt",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Než začnete kohokoľvek o čomkoľvek presviedčať, musíte pochopiť, čo sa deje v jeho hlave.
            Ak je v strese, jeho amygdala (centrum strachu) "uniesla" jeho mozog.
          </p>
          <div className="bg-red-50 p-4 rounded-xl border-l-4 border-red-500">
            <h4 className="font-bold text-red-800 text-sm mb-2">Čo sa deje?</h4>
            <ul className="text-sm text-slate-700 space-y-2">
              <li><i className="fa-solid fa-xmark text-red-400 mr-2"></i>Racionálny mozog (Systém 2) je offline.</li>
              <li><i className="fa-solid fa-check text-red-400 mr-2"></i>Človek nepočúva argumenty.</li>
              <li><i className="fa-solid fa-check text-red-400 mr-2"></i>Vníma vás ako hrozbu (nie vecnú, ale psychologickú).</li>
            </ul>
          </div>
          <p className="text-xs text-slate-500 italic">
            "Čím viac vysvetľujete človeku v odpore, tým viac ho v odpore utvrdzujete."
          </p>
        </div>
      )
    },
    {
      title: "2. Krok: Upokoj seba",
      subtitle: "Move Yourself to OK",
      icon: "fa-person-praying",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Nemôžete upokojiť iného, ak ste sami v strese. Vaše zrkadlové neuróny by preniesli vašu paniku na neho.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="bg-white p-3 border border-slate-200 rounded-lg">
                <span className="block font-bold text-red-500 text-xs mb-1">Chyba</span>
                <p className="text-xs text-slate-600">Reagovať okamžite. Brániť sa. Vysvetľovať.</p>
             </div>
             <div className="bg-white p-3 border border-green-200 rounded-lg shadow-sm">
                <span className="block font-bold text-green-600 text-xs mb-1">Riešenie</span>
                <p className="text-xs text-slate-600">Pauza. Dýchanie. Pomenovanie emócie ("Cítim hnev"). Až potom hovoriť.</p>
             </div>
          </div>
        </div>
      )
    },
    {
      title: "3. Preprogramovanie (Filtre)",
      subtitle: "Prečo nepočúvame?",
      icon: "fa-filter",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Mozog má filtre, ktoré bránia informáciám preniknúť dnu. Musíte ich obísť.
          </p>
          <ul className="space-y-2 text-sm">
            <li className="bg-slate-50 p-2 rounded flex items-center">
              <span className="font-bold mr-2 w-24 text-blue-600">Predsudky:</span> 
              <span className="text-slate-600">"On je len predajca, chce ma oklamať."</span>
            </li>
            <li className="bg-slate-50 p-2 rounded flex items-center">
              <span className="font-bold mr-2 w-24 text-blue-600">Stereotypy:</span> 
              <span className="text-slate-600">"Všetci z HR sú rovnakí."</span>
            </li>
            <li className="bg-slate-50 p-2 rounded flex items-center">
              <span className="font-bold mr-2 w-24 text-blue-600">Skákanie k záverom:</span> 
              <span className="text-slate-600">Doplnenie si príbehu, aj keď chýbajú fakty (Systém 1).</span>
            </li>
          </ul>
          <div className="bg-blue-600 text-white p-3 rounded-lg text-center text-xs font-bold">
            Cieľ: Vzdať sa potreby "mať pravdu" a nahradiť ju potrebou "byť zvedavý".
          </div>
        </div>
      )
    },
    {
      title: "4. Make feel 'Felt'",
      subtitle: "Najsilnejšia technika",
      icon: "fa-heart-circle-check",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Ľudia sa neupokoja vtedy, keď im rozumiete (hlavou), ale vtedy, keď <strong>cítia, že ich cítite</strong>.
          </p>
          <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
            <h4 className="font-bold text-indigo-800 text-sm mb-2">Postup:</h4>
            <ol className="list-decimal list-inside text-sm text-indigo-900 space-y-2">
              <li>Pomenujte emóciu: "Znie to, že si frustrovaný..."</li>
              <li>Overte to: "...je to tak?"</li>
              <li>Nechajte ich vyrozprávať sa (Ventilácia).</li>
              <li>Až keď povedia "Presne tak!", odpor sa zlomil.</li>
            </ol>
          </div>
        </div>
      )
    },
    {
      title: "5. Povedz mi viac",
      subtitle: "Magická fráza pre nahnevaných",
      icon: "fa-comment-dots",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Čo robiť, keď na vás niekto kričí alebo je agresívny?
          </p>
          <div className="bg-white border-l-4 border-orange-500 p-4 shadow-sm rounded-r-lg">
            <p className="font-bold text-slate-800 mb-1">Krok 1: Nechajte ho hovoriť</p>
            <p className="text-xs text-slate-500 mb-3">Neprerušujte. Neberte si to osobne.</p>
            
            <p className="font-bold text-slate-800 mb-1">Krok 2: Pauza</p>
            <p className="text-xs text-slate-500 mb-3">Keď skončí, počkajte sekundu.</p>
            
            <p className="font-bold text-slate-800 mb-1">Krok 3: "Povedz mi o tom viac."</p>
            <p className="text-xs text-slate-500">Toto ho donúti prejsť z emócií (S1) do vysvetľovania (S2).</p>
          </div>
        </div>
      )
    },
    {
      title: "6. Disonancia a 'Feedforward'",
      subtitle: "Riešenie vnútorného nesúladu",
      icon: "fa-scale-unbalanced",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Disonancia vzniká, keď si myslíte, že pôsobíte kompetentne, ale druhí vás vidia ako arogantného. To ničí dôveru.
          </p>
          <div className="bg-emerald-50 p-4 rounded-xl">
            <h4 className="font-bold text-emerald-800 text-sm mb-2">Technika Feedforward:</h4>
            <p className="text-xs text-emerald-700 mb-2">Namiesto kritiky minulosti sa zamerajte na budúcnosť.</p>
            <p className="text-sm font-medium italic text-emerald-900 bg-white p-2 rounded border border-emerald-100">
              "Čo sú dve veci, ktoré môžem v budúcnosti urobiť inak, aby sa nám lepšie spolupracovalo?"
            </p>
            <p className="text-xs text-emerald-600 mt-2">Jediná povolená odpoveď: "Ďakujem".</p>
          </div>
        </div>
      )
    },
    {
      title: "7. Odkry krk (Vulnerability)",
      subtitle: "Keď je všetko stratené",
      icon: "fa-user-shield",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Ak ste zahnaní do kúta, útok nepomôže. Priznanie strachu áno.
          </p>
          <div className="bg-slate-800 text-white p-4 rounded-xl shadow-lg">
            <p className="text-sm leading-relaxed mb-3">
              "Aby som bol úprimný, práve teraz sa trochu bojím. Mám pocit, že čokoľvek poviem, situáciu len zhorší. Neviem ako ďalej. Môžete mi pomôcť?"
            </p>
            <div className="text-xs text-slate-400 border-t border-slate-600 pt-2">
              <strong className="text-slate-200">Prečo to funguje:</strong> Aktivuje to zrkadlové neuróny druhej strany. Namiesto chuti "zabiť" korisť sa aktivuje pud "pomôcť".
            </div>
          </div>
        </div>
      )
    },
    {
      title: "8. Toxické Osobnosti",
      subtitle: "Kedy pravidlá nefungujú",
      icon: "fa-mask",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 text-sm">
            Existujú ľudia, s ktorými sa nedá dohodnúť bežným spôsobom.
          </p>
          <div className="space-y-2">
            <div className="bg-red-50 p-3 rounded-lg border-l-4 border-red-500">
              <strong className="block text-sm text-red-700">Narcisti</strong>
              <span className="text-xs text-slate-600">Nezaujímajú sa o vás. Ste len zrkadlo. Stratégia: Hladkajte ich ego, ale držte si hranice.</span>
            </div>
            <div className="bg-orange-50 p-3 rounded-lg border-l-4 border-orange-500">
              <strong className="block text-sm text-orange-700">Tyrani</strong>
              <span className="text-xs text-slate-600">Chcú vás vyviesť z miery. Stratégia: Očný kontakt, ticho, nuda. Nehrajte ich hru.</span>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg border-l-4 border-purple-500">
              <strong className="block text-sm text-purple-700">Upíri (Needy)</strong>
              <span className="text-xs text-slate-600">Bezodná studňa sťažností. Stratégia: Prísne časové limity. "Mám na teba 2 minúty."</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "9. Psychopati",
      subtitle: "Jediné pravidlo",
      icon: "fa-skull",
      content: (
        <div className="space-y-4 text-center">
          <div className="text-5xl text-red-600 mb-2">
            <i className="fa-solid fa-person-running"></i>
          </div>
          <h3 className="text-2xl font-black text-slate-800 uppercase tracking-widest">UTEKAJTE</h3>
          <p className="text-sm text-slate-600 text-left">
            Psychopati nemajú svedomie ani empatiu (biologický deficit). Sú charizmatickí, ale manipulatívni.
          </p>
          <div className="bg-red-600 text-white p-4 rounded-xl shadow-md font-bold text-sm">
            <i className="fa-solid fa-triangle-exclamation mr-2"></i>
            Jediná stratégia: Odísť. Žiadne vyjednávanie. Žiadny kontakt.
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="container mx-auto px-4 pt-24 pb-12 flex flex-col md:flex-row gap-6 animate-fade-in max-w-7xl">
      
      {/* Sidebar Navigation - Sticky on Desktop */}
      <div className="w-full md:w-1/3 lg:w-1/4 bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col border border-gray-100 md:h-[calc(100vh-140px)] md:sticky md:top-28">
        <div className="p-4 bg-slate-50 border-b border-gray-100 flex-shrink-0">
          <h3 className="font-bold text-gray-800">Detailný Sprievodca</h3>
          <p className="text-xs text-gray-500">{activeSlide + 1} z {slides.length} krokov</p>
        </div>
        <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar">
          {slides.map((slide, index) => (
            <button
              key={index}
              onClick={() => setActiveSlide(index)}
              className={`w-full text-left p-3 rounded-xl text-sm transition-all duration-200 flex items-center gap-3 ${
                activeSlide === index 
                  ? 'bg-blue-600 text-white shadow-md font-semibold' 
                  : 'hover:bg-slate-50 text-slate-600 hover:text-slate-900'
              }`}
            >
              <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 ${activeSlide === index ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
                <span className="text-xs font-bold">{index + 1}</span>
              </div>
              <div className="truncate">
                <div className="truncate text-xs md:text-sm">{slide.title}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div ref={contentRef} className="flex-1 bg-white rounded-2xl shadow-lg flex flex-col border border-gray-100 relative h-fit">
        {/* Header */}
        <div className="p-6 border-b border-gray-50 bg-gradient-to-r from-slate-50 to-white rounded-t-2xl">
           <div className="flex items-center gap-3 text-blue-600 mb-2">
              <i className={`fa-solid ${slides[activeSlide].icon} text-xl`}></i>
              <span className="text-[10px] font-bold tracking-widest uppercase bg-blue-100 px-2 py-0.5 rounded">Krok {activeSlide + 1}</span>
           </div>
           <h2 className="text-xl md:text-3xl font-bold text-slate-800 mb-1 leading-tight">{slides[activeSlide].title}</h2>
           {slides[activeSlide].subtitle && (
             <p className="text-sm md:text-base text-slate-500 font-light">{slides[activeSlide].subtitle}</p>
           )}
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1">
          <div className="max-w-3xl mx-auto animate-fade-in">
             {slides[activeSlide].content}
          </div>
        </div>

        {/* Footer Navigation Buttons */}
        <div className="p-4 border-t border-gray-100 flex justify-between bg-slate-50 rounded-b-2xl sticky bottom-0 z-10">
          <button 
            onClick={() => setActiveSlide(prev => Math.max(0, prev - 1))}
            disabled={activeSlide === 0}
            className={`px-5 py-2.5 rounded-xl font-medium transition-all flex items-center gap-2 text-sm ${activeSlide === 0 ? 'opacity-30 cursor-not-allowed text-slate-400' : 'bg-white hover:bg-slate-100 text-slate-700 shadow-sm'}`}
          >
            <i className="fa-solid fa-arrow-left"></i> Späť
          </button>

          <div className="flex gap-2">
             {activeSlide === slides.length - 1 ? (
                <button 
                  onClick={onBack}
                  className="px-6 py-2.5 rounded-xl font-bold bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-200 transition-all flex items-center gap-2 text-sm"
                >
                  Ukončiť <i className="fa-solid fa-check"></i>
                </button>
             ) : (
                <button 
                  onClick={() => setActiveSlide(prev => Math.min(slides.length - 1, prev + 1))}
                  className="px-6 py-2.5 rounded-xl font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200 transition-all flex items-center gap-2 text-sm"
                >
                  Ďalej <i className="fa-solid fa-arrow-right"></i>
                </button>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};