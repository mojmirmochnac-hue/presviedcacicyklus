import React, { useState, useEffect } from 'react';
import { SectionProps } from '../types';
import { ToxicPeopleView } from './ToxicPeopleView';

// --- DATA STRUCTURES FOR KAHNEMAN CONCEPTS ---
const kahnemanConcepts: Record<string, { title: string; icon: string; content: React.ReactNode }> = {
  associative: {
    title: "Asociačný stroj (The Associative Machine)",
    icon: "fa-share-nodes",
    content: (
      <div className="space-y-10 text-lg text-slate-700 leading-relaxed animate-fade-in">
        {/* Intro */}
        <div className="bg-yellow-50 p-8 rounded-2xl border-l-8 border-yellow-400 shadow-sm">
          <h3 className="text-2xl font-bold text-yellow-900 mb-4">Experiment: Alkohol a Zvracanie</h3>
          <p className="italic text-slate-700 mb-4">
            Pozrite sa na tieto dve slová:
          </p>
          <div className="text-3xl font-black text-slate-900 text-center py-4 bg-white/50 rounded-lg">
            ALKOHOL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ZVRACANIE
          </div>
          <p className="mt-4 text-slate-700">
            V priebehu poslednej sekundy sa vo vašom tele odohralo množstvo vecí. Automaticky, bez vašej vôle. 
            Váš žalúdok sa možno mierne stiahol. Urobili ste znechutenú grimasu (aj keď len mikroskopickú). 
            Dočasne sa vám "znechutil" alkohol.
          </p>
        </div>

        <p>
          Tento proces sa nazýva <strong>asociatívna aktivácia</strong>. Myšlienky vyvolávajú ďalšie myšlienky v kaskáde aktivity v mozgu.
          Zásadná vlastnosť tohto procesu je <strong>koherencia (súvislosť)</strong>. Váš Systém 1 (intuitívny mozog) sa okamžite pokúsil vytvoriť kauzálny príbeh: <em>"Alkohol spôsobil zvracanie."</em>
        </p>

        {/* Detailed Mechanism based on User Input */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
          <h4 className="font-bold text-slate-900 text-2xl mb-6 flex items-center gap-3">
            <i className="fa-solid fa-gears text-blue-500"></i>
            Ako funguje Asociačný stroj (Podľa Kahnemana)
          </h4>
          
          <p className="mb-6 text-slate-600">
            <strong>Asociačný stroj</strong> je spôsob, akým Systém 1 automaticky „spája bodky“ – bez úsilia, bez vedomého rozhodovania a často aj bez toho, aby si si všimol, že sa to deje.
          </p>

          <div className="space-y-6">
              {/* Point 1 */}
              <div className="bg-slate-50 p-5 rounded-xl border-l-4 border-blue-400">
                  <strong className="block text-slate-900 text-lg mb-2">1. Základný princíp: Aktivácia šíri aktiváciu</strong>
                  <p className="text-sm text-slate-600 mb-2">
                      Keď sa ti v hlave aktivuje jeden podnet (slovo, obraz, tón hlasu, výraz tváre), v pamäti sa automaticky aktivujú súvisiace uzly:
                  </p>
                  <div className="flex flex-wrap gap-2">
                      <span className="bg-white border border-slate-200 px-2 py-1 rounded text-xs">Pojmy a spomienky</span>
                      <span className="bg-white border border-slate-200 px-2 py-1 rounded text-xs">Emócie</span>
                      <span className="bg-white border border-slate-200 px-2 py-1 rounded text-xs">Očakávania</span>
                      <span className="bg-white border border-slate-200 px-2 py-1 rounded text-xs">Hodnotenia (dobré/zlé)</span>
                      <span className="bg-white border border-slate-200 px-2 py-1 rounded text-xs">Typické reakcie</span>
                  </div>
              </div>

              {/* Point 2 */}
              <div className="bg-slate-50 p-5 rounded-xl border-l-4 border-indigo-400">
                  <strong className="block text-slate-900 text-lg mb-2">2. Asociatívna pamäť je „sieť“, nie zoznam</strong>
                  <p className="text-sm text-slate-600 mb-3">
                      Systém 1 nepracuje ako Excel tabuľka, ale ako sieť prepojení. Stačí malý signál a spustí sa celý "balík".
                  </p>
                  <div className="flex flex-wrap items-center gap-2 text-sm bg-white p-3 rounded-lg border border-slate-100">
                      <span className="font-bold text-slate-700">Reťazec:</span>
                      <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded">Klient</span>
                      <i className="fa-solid fa-arrow-right text-slate-300"></i>
                      <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded">Sťažnosť</span>
                      <i className="fa-solid fa-arrow-right text-slate-300"></i>
                      <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded">Napätie</span>
                      <i className="fa-solid fa-arrow-right text-slate-300"></i>
                      <span className="bg-red-50 text-red-600 font-bold px-2 py-1 rounded">Obrana</span>
                  </div>
              </div>

              {/* Point 3 */}
              <div className="bg-slate-50 p-5 rounded-xl border-l-4 border-purple-400">
                  <strong className="block text-slate-900 text-lg mb-2">3. Produkuje „dojmy“ a „príbehy“</strong>
                  <p className="text-sm text-slate-600">
                      Kahneman zdôrazňuje, že väčšina toho, čo považujeme za „myslenie“, je v skutočnosti hotový dojem („tohto človeka nemám rád“) alebo hotové vysvetlenie („určite ma chce oklamať“), ktoré sa objavia vo vedomí bez toho, aby si videl proces ich vzniku.
                  </p>
              </div>

              {/* Point 4 */}
              <div className="bg-slate-50 p-5 rounded-xl border-l-4 border-orange-400">
                  <strong className="block text-slate-900 text-lg mb-2">4. Rýchly, ale robí chyby</strong>
                  <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      <li>Uprednostní to, čo je živé a ľahko predstaviteľné pred štatistikou.</li>
                      <li>Z mála indícií vytvorí pevný záver.</li>
                      <li>Je citlivý na kontext (to, čo si práve počul/videl, mení úsudok).</li>
                  </ul>
              </div>

              {/* Point 5 - Key for communication */}
              <div className="bg-blue-50 p-5 rounded-xl border border-blue-200">
                  <strong className="block text-blue-900 text-lg mb-2 flex items-center gap-2">
                      <i className="fa-solid fa-key"></i> Prečo je to kľúčové v komunikácii?
                  </strong>
                  <p className="text-sm text-blue-800 mb-3">
                      Keď je klient v odpore, často nepočúva „argument“, ale jeho Systém 1 cez asociácie vyhodnocuje hrozby.
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-xs font-bold text-slate-600">
                      <div className="bg-white p-2 rounded shadow-sm">„Toto je hrozba?“</div>
                      <div className="bg-white p-2 rounded shadow-sm">„Cítim sa pod tlakom?“</div>
                      <div className="bg-white p-2 rounded shadow-sm">„Chce ma zmanipulovať?“</div>
                      <div className="bg-white p-2 rounded shadow-sm">„Mám sa brániť?“</div>
                  </div>
                  <p className="text-sm text-blue-800 mt-3 italic">
                      Preto tlak a presviedčanie často zvyšujú odpor: aktivujú ďalšie obranné asociácie.
                  </p>
              </div>
          </div>
        </div>

        {/* Research Examples */}
        <div className="mt-4">
            <h4 className="font-bold text-slate-900 text-xl mb-6">Príklady z výskumu (Embodied Cognition)</h4>
            <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-slate-50 p-6 rounded-2xl shadow-sm">
                    <strong className="block text-slate-900 mb-2 text-lg">1. Ideomotorický efekt (Florida)</strong>
                    <p className="text-sm text-slate-600 mb-2">
                        Myšlienky ovplyvňujú činy. V experimente (Bargh) študenti skladali vety zo slov ako <em>Florida, zábudlivý, šedivý</em>.
                    </p>
                    <p className="text-sm text-slate-800 font-semibold border-t border-slate-200 pt-2 mt-2">
                        Výsledok: Keď odchádzali, kráčali preukázateľne pomalšie, hoci slovo "starý" nikdy nepadlo.
                    </p>
                </div>
                <div className="bg-slate-50 p-6 rounded-2xl shadow-sm">
                    <strong className="block text-slate-900 mb-2 text-lg">2. Recipročný efekt</strong>
                    <p className="text-sm text-slate-600 mb-2">
                        Funguje to aj naopak. Ak sa usmievate (držíte ceruzku v zuboch), vtipy sa vám zdajú smiešnejšie. Ak sa mračíte, svet sa zdá kritickejší.
                    </p>
                    <p className="text-sm text-slate-800 font-semibold border-t border-slate-200 pt-2 mt-2">
                        Záver: Váš fyzický stav diktuje vaše myšlienky.
                    </p>
                </div>
            </div>
        </div>

        {/* Priming */}
        <div className="bg-slate-50 p-8 rounded-2xl border border-slate-200">
            <h4 className="font-bold text-slate-900 text-2xl mb-4">Zázrak Primingu (Podnecovania)</h4>
            <p className="mb-4">
            Priming nie je len o slovách. Je to o prostredí. V experimente v britskej kuchynke (Honesty Box) ľudia platili za kávu do "kasičky čestnosti".
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4 mb-6 text-sm text-slate-700">
            <li>Keď bol nad kasičkou plagát s <strong>kvetmi</strong>, ľudia platili málo.</li>
            <li>Keď bol nad kasičkou plagát s <strong>očami</strong> (ktoré sa na nich "pozerali"), príspevky sa <strong> strojnásobili</strong>.</li>
            </ul>
            <p className="text-slate-800 font-medium">
            <strong>Aplikácia pre "Just Listen":</strong> Ak chcete, aby bol niekto otvorený, musíte vytvoriť "prostredie bezpečia" (prikývnite, usmejte sa, použite jeho meno). Ak začnete útokom alebo kritikou, "naprimujete" (podnietite) jeho obranu skôr, než poviete prvý argument.
            </p>
        </div>
      </div>
    )
  },
  ease: {
    title: "Kognitívna plynulosť (Cognitive Ease)",
    icon: "fa-feather",
    content: (
      <div className="space-y-10 text-lg text-slate-700 leading-relaxed animate-fade-in">
        {/* Intro Concept */}
        <div className="bg-white p-6 rounded-2xl border-l-8 border-green-500 shadow-sm">
          <p className="text-lg text-slate-800 leading-relaxed">
            Predstavte si, že v kokpite vášho mozgu je jeden hlavný ciferník. Ručička sa pohybuje medzi dvoma stavmi: 
            <strong> „Ľahko“ (Easy)</strong> a <strong>„Namáhavo“ (Strained)</strong>.
          </p>
          <p className="mt-4 text-slate-600">
            Systém 1 neustále monitoruje prostredie: <em>Deje sa niečo nové? Je tu hrozba? Ide všetko hladko?</em>
            <br/>
            Ak ručička ukazuje <strong>„Ľahko“</strong>, znamená to, že nie sú žiadne hrozby, netreba presmerovať pozornosť a nie je potrebná mobilizácia úsilia. Ste v bezpečí, ale ste tiež povrchní v myslení.
          </p>
        </div>

        {/* The Diagram (Causes & Consequences) */}
        <div className="bg-slate-50 p-8 rounded-3xl border border-slate-200">
           <h3 className="text-center text-2xl font-bold text-slate-900 mb-8">Príčiny a Dôsledky (Causes & Consequences)</h3>
           
           <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-12">
              
              {/* Causes (Inputs) */}
              <div className="space-y-3 w-full md:w-auto">
                 <div className="bg-white border border-slate-300 px-4 py-2 text-center rounded shadow-sm text-sm font-semibold">Opakovaná skúsenosť</div>
                 <div className="bg-white border border-slate-300 px-4 py-2 text-center rounded shadow-sm text-sm font-semibold">Jasné zobrazenie (Font)</div>
                 <div className="bg-white border border-slate-300 px-4 py-2 text-center rounded shadow-sm text-sm font-semibold">Naprimovaný nápad</div>
                 <div className="bg-white border border-slate-300 px-4 py-2 text-center rounded shadow-sm text-sm font-semibold">Dobrá nálada</div>
              </div>

              {/* Central Processor */}
              <div className="relative">
                 <div className="hidden md:block absolute -left-8 top-1/2 -translate-y-1/2 text-slate-400 text-4xl">→</div>
                 <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white font-black text-xl px-8 py-6 rounded-2xl shadow-xl z-10 relative uppercase tracking-widest">
                    Plynulosť<br/>(EASE)
                 </div>
                 <div className="hidden md:block absolute -right-8 top-1/2 -translate-y-1/2 text-slate-400 text-4xl">→</div>
                 <div className="md:hidden text-center text-slate-400 text-2xl my-2">↓</div>
              </div>

              {/* Consequences (Outputs) */}
              <div className="space-y-3 w-full md:w-auto">
                 <div className="bg-white border-l-4 border-green-500 px-4 py-2 rounded shadow-sm text-sm font-semibold">Pôsobí POVEDOME</div>
                 <div className="bg-white border-l-4 border-green-500 px-4 py-2 rounded shadow-sm text-sm font-semibold">Pôsobí PRAVDIVO</div>
                 <div className="bg-white border-l-4 border-green-500 px-4 py-2 rounded shadow-sm text-sm font-semibold">Pôsobí DOBRE</div>
                 <div className="bg-white border-l-4 border-green-500 px-4 py-2 rounded shadow-sm text-sm font-semibold">Pôsobí BEZ NÁMAHY</div>
              </div>
           </div>
           
           <p className="text-center text-xs text-slate-500 mt-8 italic max-w-lg mx-auto">
             *Tieto stavy sú zameniteľné. Ak sa usmievate (hoci len preto, že máte ceruzku v zuboch), svet sa zdá jednoduchší a pravdivejší. Ak je text ťažko čitateľný, cítite napätie.
           </p>
        </div>

        {/* Illusions of Remembering */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
           <h4 className="font-bold text-slate-900 text-2xl mb-4 flex items-center gap-3">
              <i className="fa-solid fa-clock-rotate-left text-blue-500"></i>
              Ilúzia pamäte: "Stať sa slávnym cez noc"
           </h4>
           <p className="text-slate-700 mb-4">
              Psychológ Larry Jacoby ukázal ľuďom zoznam vymyslených mien (napr. <em>David Stenbill</em>). 
              O pár dní im ukázal dlhý zoznam mien, kde boli celebrity (Einstein, Bono) aj vymyslené mená.
              Ľudia označili Davida Stenbilla za "slávnu osobu". Prečo?
           </p>
           <div className="bg-blue-50 p-4 rounded-xl border-l-4 border-blue-400 text-sm text-blue-900">
              <strong>Vysvetlenie:</strong> Keď vidíte meno druhýkrát, prečítate ho ľahšie (Cognitive Ease). 
              Váš mozog si túto ľahkosť interpretuje ako <strong>„Pocit známosti“ (Pastness)</strong>. 
              Systém 1 nerozlišuje medzi <em>„toto meno som videl včera v laboratóriu“</em> a <em>„toto meno poznám, lebo je slávne“</em>. Má len pocit známosti.
           </div>
        </div>

        {/* Illusions of Truth */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
           <h4 className="font-bold text-slate-900 text-2xl mb-4 flex items-center gap-3">
              <i className="fa-solid fa-check-double text-emerald-500"></i>
              Ilúzia pravdy
           </h4>
           <p className="text-slate-700 mb-6">
              "Kura má štyri nohy." vs. "Kura má tri nohy." Prvá veta sa zdá "pravdivejšia" (hoci je lož), pretože evokuje viac asociácií so zvieratami so štyrmi nohami.
              Čokoľvek, čo uľahčí prácu asociačnému stroju, skreslí vaše presvedčenia.
           </p>

           <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-slate-50 p-6 rounded-xl">
                 <h5 className="font-bold text-slate-800 mb-2">Experiment s Hitlerom</h5>
                 <div className="space-y-4">
                    <div>
                       <p className="font-bold text-slate-900 text-xl">Adolf Hitler sa narodil v roku 1892.</p>
                       <p className="text-xs text-slate-500">Ľudia tejto vete verili viac.</p>
                    </div>
                    <div>
                       <p className="font-light text-slate-400 text-sm">Adolf Hitler sa narodil v roku 1887.</p>
                       <p className="text-xs text-slate-500">Túto vetu ľudia odmietali.</p>
                    </div>
                 </div>
                 <p className="mt-4 text-sm text-slate-700 font-semibold border-t border-slate-200 pt-2">
                    Obe sú nepravdivé (1889). Ale tá tučná a jasná vytvára Kognitívnu plynulosť, ktorú mozog zamieňa za Pravdu.
                 </p>
              </div>
              <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                 <h5 className="font-bold text-red-900 mb-2">Opakovanie je matka klamstva</h5>
                 <p className="text-sm text-red-800 leading-relaxed">
                    Autoritárske režimy a marketéri to vedia: Nemusíte opakovať celý fakt. Stačí opakovať fragmenty.
                    Ak stokrát počujete <em>"telesná teplota kuraťa"</em>, neskôr ľahšie uveríte vete <em>"telesná teplota kuraťa je 60°C"</em> (čo je nezmysel), len preto, že tá fráza vám znie povedome.
                    <strong>Známosť sa nedá ľahko odlíšiť od pravdy.</strong>
                 </p>
              </div>
           </div>
        </div>

        {/* Persuasive Writing Tips */}
        <div className="bg-indigo-50 p-8 rounded-2xl border border-indigo-100">
           <h4 className="font-bold text-indigo-900 text-2xl mb-6">Praktické: Ako písať presvedčivú správu?</h4>
           <p className="text-indigo-800 mb-4">
              Ak chcete, aby vám ľudia verili, musíte znížiť ich kognitívne napätie.
           </p>
           
           <ul className="space-y-3">
              <li className="flex items-start gap-3 bg-white p-3 rounded-lg shadow-sm">
                 <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0 mt-0.5"><i className="fa-solid fa-check text-xs"></i></div>
                 <div>
                    <strong className="block text-slate-800 text-sm">Maximalizujte kontrast</strong>
                    <span className="text-xs text-slate-600">Použite kvalitný papier, čierne/modré/červené písmo na bielom. Nikdy nie žlté na bielom.</span>
                 </div>
              </li>
              <li className="flex items-start gap-3 bg-white p-3 rounded-lg shadow-sm">
                 <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0 mt-0.5"><i className="fa-solid fa-check text-xs"></i></div>
                 <div>
                    <strong className="block text-slate-800 text-sm">Jednoduchý jazyk</strong>
                    <span className="text-xs text-slate-600">
                       Nepoužívajte zložité slová ("Erudite Vernacular"), ak stačia jednoduché. 
                       Mýtus, že zložité slová zvyšujú inteligenciu, je vyvrátený. Zložitý jazyk = Nízka kredibilita.
                    </span>
                 </div>
              </li>
              <li className="flex items-start gap-3 bg-white p-3 rounded-lg shadow-sm">
                 <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0 mt-0.5"><i className="fa-solid fa-check text-xs"></i></div>
                 <div>
                    <strong className="block text-slate-800 text-sm">Rýmovanie (Aphorisms)</strong>
                    <span className="text-xs text-slate-600">
                       "Woes unite foes" (Bieda spája nepriateľov) bola hodnotená ako múdrejšia myšlienka než "Woes unite enemies", len vďaka rýmu.
                    </span>
                 </div>
              </li>
              <li className="flex items-start gap-3 bg-white p-3 rounded-lg shadow-sm">
                 <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0 mt-0.5"><i className="fa-solid fa-check text-xs"></i></div>
                 <div>
                    <strong className="block text-slate-800 text-sm">Vysloviteľnosť mena</strong>
                    <span className="text-xs text-slate-600">
                       Akcie firiem s ľahko vysloviteľnými skratkami (KAR, LUNMOO) si vedú na burze lepšie než tie zložité (PXG, RDO).
                       Systém 2 je lenivý a vyhýba sa čomukoľvek, čo vyžaduje úsilie (napr. vysloviť zložité meno).
                    </span>
                 </div>
              </li>
           </ul>
        </div>

        {/* Strain and System 2 */}
        <div className="bg-slate-800 text-white p-8 rounded-2xl shadow-xl">
           <div className="flex items-start gap-4">
              <div className="text-3xl text-orange-400"><i className="fa-solid fa-glasses"></i></div>
              <div>
                 <h4 className="font-bold text-xl mb-2">Kedy je „Napätie“ (Strain) dobré?</h4>
                 <p className="text-slate-300 text-sm leading-relaxed mb-4">
                    Keď cítite kognitívne napätie, mobilizuje sa Systém 2. Ste podozrievavejší, menej intuitívny, ale robíte menej chýb.
                 </p>
                 <div className="bg-slate-700 p-4 rounded-xl text-sm">
                    <strong>Experiment (CRT Test):</strong>
                    <br/>
                    Keď dostali študenti logické hádanky vytlačené <strong>šedým, ťažko čitateľným písmom</strong>, ich úspešnosť paradoxne <strong>STÚPLA z 10% na 65%</strong>.
                    <br/><br/>
                    Prečo? Zlá čitateľnosť vyvolala kognitívne napätie -> to prebudilo Systém 2 -> ten odhalil chyták, ktorý by inak lenivý Systém 1 prehliadol.
                 </div>
              </div>
           </div>
        </div>

        {/* Mere Exposure Effect */}
        <div className="space-y-4">
           <h4 className="font-bold text-slate-900 text-2xl">Efekt čistej expozície (Mere Exposure Effect)</h4>
           <p className="text-slate-700">
              Psychológ Robert Zajonc zistil, že opakovanie ľubovoľného podnetu vytvára náklonnosť.
              Experimentoval s nezmyselnými slovami (<em>kadirga, saricik</em>) v univerzitných novinách. Slová, ktoré sa objavovali najčastejšie, boli neskôr študentmi hodnotené ako "najpozitívnejšie".
           </p>
           <p className="bg-green-50 p-4 border-l-4 border-green-500 text-green-800 text-sm italic">
              "Biologický zmysel: Ak niečo vidím opakovane a ešte ma to nezabilo, je to pravdepodobne bezpečné. Bezpečie = Dobrý pocit."
           </p>
        </div>

        {/* Mood and Intuition */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl border border-purple-100">
           <h4 className="font-bold text-purple-900 text-2xl mb-4">Nálada a Intuícia (RAT Test)</h4>
           <p className="text-slate-700 mb-4">
              Pozrite sa na tieto tri slová. Čo ich spája?
           </p>
           <div className="flex gap-4 justify-center mb-6 font-mono font-bold text-lg text-slate-800">
              <span>COTTAGE</span>
              <span>SWISS</span>
              <span>CAKE</span>
           </div>
           <p className="text-center text-sm text-slate-500 mb-6">(Riešenie: CHEESE - Cottage cheese, Swiss cheese, Cheesecake)</p>
           
           <p className="text-slate-700">
              Experimenty ukázali úžasnú vec: Ľudia dokážu "vycítiť", že trojica slov má riešenie ešte predtým, než to riešenie nájdu. Cítia jemnú kognitívnu plynulosť (úľavu).
              <br/><br/>
              <strong>Vplyv nálady:</strong>
           </p>
           <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                 <span className="text-green-500 font-bold">😊 Dobrá nálada:</span>
                 <span>Zdvojnásobuje presnosť intuície. Uvoľňuje Systém 1. Zvyšuje kreativitu, ale aj dôverčivosť.</span>
              </li>
              <li className="flex items-center gap-2">
                 <span className="text-red-500 font-bold">☹️ Zlá nálada:</span>
                 <span>Úplne vypína intuíciu. Ľudia neboli schopní uhádnuť súvislosť. Aktivuje ostražitosť a Systém 2.</span>
              </li>
           </ul>
        </div>

        {/* Practical Application for KP */}
        <div className="bg-slate-900 text-slate-200 p-8 rounded-2xl border border-slate-700 shadow-xl">
            <h4 className="font-bold text-white text-2xl mb-6 flex items-center gap-3">
                <i className="fa-solid fa-briefcase text-blue-400"></i>
                Aplikácia pre prax (Ako to využiť pri klientovi)
            </h4>
            <div className="grid md:grid-cols-2 gap-8">
                <div>
                    <h5 className="font-bold text-green-400 mb-2 uppercase text-sm tracking-wider">Keď chcete "ÁNO" (Predaj)</h5>
                    <p className="text-sm mb-4 text-slate-400">
                        Cieľom je udržať klienta v <strong>Kognitívnej plynulosti (Ease)</strong>. Nechcete prebudiť jeho kritický Systém 2.
                    </p>
                    <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Vizuálna čistota:</strong> Zmluvy a prezentácie musia byť na kvalitnom papieri, s vysokým kontrastom a jednoduchým fontom.</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Jednoduchý jazyk:</strong> Hovorte "ľudsky". Odborné termíny zvyšujú napätie a podozrievavosť.</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Nálada:</strong> Pred dôležitým rozhodnutím klienta rozosmejte alebo uvoľnite. Dobrá nálada = Dôvera.</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h5 className="font-bold text-orange-400 mb-2 uppercase text-sm tracking-wider">Keď chcete "POZOR" (Riziko)</h5>
                    <p className="text-sm mb-4 text-slate-400">
                        Ak chcete, aby klient spomalil a premýšľal (napr. aby neurobil unáhlenú chybu alebo keď mu vysvetľujete vážne riziká), musíte vyvolať <strong>Kognitívne napätie (Strain)</strong>.
                    </p>
                    <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-triangle-exclamation text-orange-500 mt-1"></i>
                            <span><strong>Zmeňte formát:</strong> Použite menej čitateľný font alebo zložitejšiu štruktúru vety. To donúti mozog zapnúť Systém 2.</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-triangle-exclamation text-orange-500 mt-1"></i>
                            <span><strong>Vážny tón:</strong> Prestaňte sa usmievať. Vážna tvár signalizuje "Problém" a aktivuje ostražitosť.</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div className="mt-6 pt-6 border-t border-slate-700 text-center italic text-sm text-slate-400">
                "Pamätajte: Ľudia veria tomu, čo sa číta ľahko. Ak je vaša ponuka zložitá a neprehľadná, klient bude mať pocit, že nie je pravdivá alebo bezpečná."
            </div>
        </div>

      </div>
    )
  },
  wysiati: {
    title: "WYSIATI (What You See Is All There Is)",
    icon: "fa-eye-slash",
    content: (
      <div className="space-y-10 text-lg text-slate-700 leading-relaxed animate-fade-in">
        <div className="bg-indigo-900 text-white p-8 rounded-2xl shadow-xl">
            <h3 className="text-2xl font-bold mb-4 text-center">To, čo vidíš, je všetko, čo existuje</h3>
            <p className="text-center text-indigo-200">
                Systém 1 nie je citlivý na to, koľko informácií mu chýba. Vytvorí najlepší možný príbeh z informácií, ktoré má práve teraz k dispozícii.
                <br/><br/>
                <strong>Zásadné pravidlo:</strong> Systém 1 sa nepýta <em>"Aké dôkazy mi chýbajú?"</em>. Pýta sa len <em>"Sedí tento príbeh?"</em>
            </p>
        </div>

        {/* Consistency is King */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
            <h4 className="font-bold text-slate-900 text-2xl mb-4">Sila koherencie (Súvislosti)</h4>
            <p className="text-slate-600 mb-6">
                Mierou úspechu pre Systém 1 je <strong>koherencia príbehu</strong> (ako dobre do seba veci zapadajú), nie množstvo alebo kvalita dôkazov.
            </p>
            <div className="flex flex-col md:flex-row gap-6 items-center">
                <div className="bg-indigo-50 p-6 rounded-xl flex-1 w-full">
                    <strong className="block text-indigo-900 mb-2">Paradox sebadôvery</strong>
                    <p className="text-sm text-indigo-800">
                        Často sme si najistejší práve vtedy, keď vieme najmenej. Prečo? Pretože keď máte málo informácií, je ľahké vytvoriť z nich perfektný, nerozporný príbeh.
                        <br/><br/>
                        <em>Viac informácií = Viac rozporov = Menšia istota.</em>
                    </p>
                </div>
                <div className="text-4xl text-slate-300 hidden md:block">
                    <i className="fa-solid fa-arrow-right"></i>
                </div>
                <div className="bg-slate-50 p-6 rounded-xl flex-1 w-full border-l-4 border-slate-400">
                    <strong className="block text-slate-900 mb-2">Jednostranné dôkazy</strong>
                    <p className="text-sm text-slate-600">
                        Keď počujeme len jednu stranu prípadu (napr. žalobcu), sme si extrémne istí vinou. Náš mozog si nevie predstaviť argumenty obhajoby, ktoré ešte nepočul. Pre Systém 1 neexistujú.
                    </p>
                </div>
            </div>
        </div>

        {/* Experiment Ivana */}
        <div className="bg-slate-100 p-8 rounded-2xl border border-slate-200">
            <h4 className="font-bold text-slate-900 text-2xl mb-4">Experiment: Líderka Ivana </h4>
            <p className="mb-4 text-slate-700">Zvážte nasledujúci popis osoby:</p>
            <div className="border-l-4 border-indigo-500 pl-4 py-3 italic text-slate-800 bg-white shadow-sm mb-6 text-lg font-medium">
                "Bude Ivana dobrým lídrom? Je inteligentná a silná..."
            </div>
            <p className="text-slate-700">
                Vaša okamžitá odpoveď bola "Áno". Vytvorili ste si obraz úspešnej ženy.
                Ale čo ak by veta pokračovala: <em>"...ale je skorumpovaná a krutá"</em>?
            </p>
            <div className="mt-4 p-4 bg-yellow-50 text-yellow-900 rounded-xl text-sm font-semibold border border-yellow-200">
                <i className="fa-solid fa-lightbulb mr-2"></i>
                Kľúčové zistenie: Kým som vám nepovedal o korupcii, táto možnosť pre váš mozog <strong>neexistovala</strong>. 
                Nečakal ste na ďalšie informácie. Okamžite ste vytvorili hodnotenie na základe dvoch slov. Prvé dojmy (Halo Efekt) majú obrovskú váhu, pretože pre Systém 1 sú "všetkým, čo existuje".
            </div>
        </div>

        {/* Consequences */}
        <div>
            <h4 className="font-bold text-slate-900 text-xl mb-6">Tri fatálne dôsledky WYSIATI</h4>
            <div className="space-y-4">
                <div className="flex gap-4 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0">1</div>
                    <div>
                        <h5 className="font-bold text-slate-800">Nadmerná sebadôvera (Overconfidence)</h5>
                        <p className="text-sm text-slate-600 mt-1">
                            Naša istota nezávisí od kvality dôkazov, ale od kvality príbehu. Sme schopní veriť nezmyslom, ak sú podané koherentne.
                        </p>
                    </div>
                </div>

                <div className="flex gap-4 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0">2</div>
                    <div>
                        <h5 className="font-bold text-slate-800">Efekt rámcovania (Framing Effects)</h5>
                        <p className="text-sm text-slate-600 mt-1">
                            <em>"Mäso je na 90% bez tuku"</em> vs. <em>"Mäso obsahuje 10% tuku"</em>.
                            Logicky sú rovnaké. Ale pre WYSIATI je v prvom prípade viditeľné "bez tuku" (dobré) a v druhom "tuk" (zlé).
                        </p>
                    </div>
                </div>

                <div className="flex gap-4 p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0">3</div>
                    <div>
                        <h5 className="font-bold text-slate-800">Ignorovanie štatistiky (Base-rate neglect)</h5>
                        <p className="text-sm text-slate-600 mt-1">
                            Keď vidíme detailný popis osoby (napr. "miluje poriadok"), okamžite ju zaradíme ako "knihovníka", a ignorujeme fakt, že štatisticky je v populácii oveľa viac farmárov ako knihovníkov. Vidíme popis, nevidíme štatistiku.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        {/* Practical Application for KP */}
        <div className="bg-slate-900 text-slate-200 p-8 rounded-2xl border border-slate-700 shadow-xl mt-8">
            <h4 className="font-bold text-white text-2xl mb-6 flex items-center gap-3">
                <i className="fa-solid fa-briefcase text-blue-400"></i>
                Aplikácia pre prax (Ako to využiť v obchode)
            </h4>
            <p className="text-slate-400 mb-6 text-sm">
                Keďže klientov mozog ignoruje to, čo nevidí, máte obrovskú moc: <strong>Ovládate ich realitu tým, čo im ukážete (a čo zamlčíte).</strong>
            </p>
            
            <div className="grid md:grid-cols-2 gap-8">
                <div>
                    <h5 className="font-bold text-white mb-2 text-sm uppercase tracking-wider border-b border-slate-700 pb-2">Kontrola informácií</h5>
                    <p className="text-sm mb-4 text-slate-400">
                        Klient nebude pátrať po chýbajúcich informáciách, ak je váš príbeh dobrý.
                    </p>
                    <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Príbeh vyhráva:</strong> Neprezentujte len dáta. Vytvorte koherentný príbeh, prečo váš produkt rieši ich problém. Ak to "sedí", uveria tomu.</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Nevyvolávajte pochybnosti:</strong> Ak sami spomeniete, že "možno to nie je dokonalé", rozbijete koherenciu. Nechajte klienta, nech si pochybnosti nájde sám (ak to dokáže).</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h5 className="font-bold text-white mb-2 text-sm uppercase tracking-wider border-b border-slate-700 pb-2">Rámcovanie a Prvý dojem</h5>
                    <p className="text-sm mb-4 text-slate-400">
                        To, čo vidia ako prvé, zafarbí všetko ostatné.
                    </p>
                    <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Halo Efekt:</strong> Začnite tým najsilnejším a najpozitívnejším bodom. Ak vás na začiatku vnímajú ako experta, odpustia vám neskôr malé chyby.</span>
                        </li>
                        <li className="flex items-start gap-2">
                            <i className="fa-solid fa-check text-green-500 mt-1"></i>
                            <span><strong>Framing:</strong> Nikdy nehovorte "máme 5% chybovosť". Hovorte "máme 95% úspešnosť". Pre Systém 1 sú to dve úplne odlišné reality.</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
      </div>
    )
  },
  substitution: {
    title: "Substitúcia a Heuristiky (Substitution)",
    icon: "fa-arrows-rotate",
    content: (
      <div className="space-y-12 text-lg text-slate-700 leading-relaxed animate-fade-in">
        <div className="bg-white p-6 rounded-2xl border-l-8 border-red-500 shadow-sm">
          <p className="font-medium text-slate-800 italic text-xl mb-4">
            "Ak neexistuje uspokojivá odpoveď na ťažkú otázku, Systém 1 nájde ľahšiu príbuznú otázku a odpovie na ňu."
          </p>
          <p>
            Toto je definícia substitúcie. Predstavte si, že máte v práci vyriešiť zložitý problém. Čo urobí lenivý zamestnanec? Nájde si ľahšiu úlohu, vyrieši tú, a tvári sa, že vyriešil tú pôvodnú. Presne toto robí váš mozog neustále – a vy si to ani nevšimnete.
          </p>
        </div>

        <div>
           <h3 className="text-2xl font-bold text-slate-900 mb-4">Proces v 4 krokoch</h3>
           <p className="mb-6">
             Ako sa z ťažkej otázky stane ľahká odpoveď?
           </p>
           
           <div className="grid md:grid-cols-2 gap-8">
              {/* Mental Shotgun */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-3 mb-3 text-red-600">
                    <i className="fa-solid fa-burst text-2xl"></i>
                    <h4 className="font-bold text-lg">1. Mentálna brokovnica</h4>
                  </div>
                  <p className="text-sm">
                    Systém 1 nedokáže "vystreliť" presne na jeden bod. Vždy trafí aj okolie. Keď dostane otázku, aktivuje sa nielen relevantná informácia, ale aj množstvo asociácií, pocitov a spomienok. Vzniká prebytok informácií.
                  </p>
              </div>

              {/* Substitution */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-3 mb-3 text-blue-600">
                    <i className="fa-solid fa-arrow-right-arrow-left text-2xl"></i>
                    <h4 className="font-bold text-lg">2. Výmena otázok</h4>
                  </div>
                  <p className="text-sm">
                    Systém 1 narazí na ťažkú <strong>Cieľovú otázku</strong>. Zistí, že odpoveď vyžaduje prácu (Systém 2). Aby ušetril energiu, nájde v "brokovnici" ľahšiu <strong>Heuristickú otázku</strong>, na ktorú už má odpoveď (zvyčajne emóciu).
                  </p>
              </div>
           </div>
        </div>

        {/* Example: Dolphins */}
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-8 rounded-3xl border border-indigo-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5 text-9xl text-indigo-900 pointer-events-none">
              <i className="fa-solid fa-fish-fins"></i>
            </div>
            
            <h3 className="text-2xl font-bold text-indigo-900 mb-6 relative z-10">Príklad 1: Záchrana delfínov</h3>
            <p className="mb-6 relative z-10">
              Predstavte si, že sa vás anketár spýta:
            </p>

            <div className="grid md:grid-cols-2 gap-6 relative z-10">
                <div className="bg-white p-6 rounded-xl shadow-sm border-2 border-red-100">
                    <div className="uppercase tracking-wider text-xs font-bold text-red-500 mb-2">Cieľová otázka (Ťažká)</div>
                    <h4 className="font-bold text-lg mb-2">"Koľko dolárov by ste prispeli na záchranu ohrozených delfínov?"</h4>
                    <p className="text-xs text-slate-500">
                        Aby ste odpovedali racionálne, musíte vedieť: Aký mám rozpočet? Koľko stojí záchrana? Je táto charita efektívna?
                        <br/><strong>Systém 2:</strong> "To je veľa počítania..."
                    </p>
                </div>

                <div className="flex items-center justify-center md:hidden">
                    <i className="fa-solid fa-arrow-down text-indigo-300 text-2xl"></i>
                </div>
                <div className="hidden md:flex items-center justify-center">
                    <i className="fa-solid fa-arrow-right text-indigo-300 text-2xl"></i>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border-2 border-green-100">
                    <div className="uppercase tracking-wider text-xs font-bold text-green-600 mb-2">Heuristická otázka (Ľahká)</div>
                    <h4 className="font-bold text-lg mb-2">"Čo cítim, keď si predstavím umierajúceho delfína?"</h4>
                    <p className="text-xs text-slate-500">
                        Toto je okamžité. Cítim smútok a ľútosť.
                        <br/><strong>Systém 1:</strong> "Mám odpoveď! Cítim veľký smútok."
                    </p>
                </div>
            </div>

            <div className="mt-8 bg-white/60 p-6 rounded-xl relative z-10">
                <h4 className="font-bold text-indigo-900 mb-2">Krok 3: Intensity Matching (Preklad)</h4>
                <p className="text-sm text-indigo-800">
                    Máte odpoveď "Veľký smútok". Ale anketár chce doláre.
                    Mozog použije <strong>Matching Intenzity</strong>. Vie priradiť intenzitu z jednej škály (emócie) na druhú (peniaze).
                    <br/><br/>
                    <em>"Veľmi smutné" (v škále pocitov) = "Veľa peňazí" (v škále vašich darov).</em>
                    <br/><br/>
                    Výsledok: Suma, ktorú darujete, neodráža potrebu organizácie, ale to, <strong>ako veľmi sa vám páčia delfíny</strong> (Affect Heuristic).
                </p>
            </div>
        </div>

        {/* Example: 3D Illusion */}
        <div className="grid md:grid-cols-5 gap-8 items-center">
            <div className="md:col-span-3">
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Príklad 2: 3D Heuristika (Ilúzia)</h3>
                <p className="mb-4">
                    Kahneman uvádza príklad optickej ilúzie, kde sú tri postavy v chodbe.
                    Spýtam sa vás: <em>"Ktorá postava je najväčšia na papieri (v milimetroch)?"</em>
                </p>
                <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm text-slate-600">
                        <i className="fa-solid fa-xmark text-red-500"></i>
                        <span><strong>Cieľová otázka:</strong> 2D veľkosť na papieri. (Ťažké, treba pravítko).</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-600">
                        <i className="fa-solid fa-check text-green-500"></i>
                        <span><strong>Heuristická otázka:</strong> Ktorá postava je najväčšia v 3D priestore? (Ľahké, vidím perspektívu).</span>
                    </div>
                </div>
                <p className="mt-4 text-sm bg-slate-100 p-4 rounded-lg">
                    Váš Systém 1 automaticky vníma hĺbku. Vidí, že tá vzadu je "ďalej", takže ak vyzerá rovnako veľká, v skutočnosti musí byť obrovská.
                    Odpovie vám: <strong>"Tá vzadu je najväčšia."</strong>
                    <br/>
                    Aj keď vezmete pravítko a zmeriate, že sú na milimeter rovnaké, <strong>nemôžete ich vidieť rovnako</strong>. Substitúcia prebehla automaticky a nedá sa vypnúť.
                </p>
            </div>
            <div className="md:col-span-2 flex flex-col items-center justify-center p-4">
                 <svg viewBox="0 0 500 400" className="w-full h-auto bg-white rounded-2xl shadow-inner border border-slate-200">
                    <defs>
                      <symbol id="man-figure" viewBox="0 0 100 200">
                         <path d="M50 20 C 65 20 65 45 50 45 C 35 45 35 20 50 20 Z M 50 50 C 80 50 90 80 90 130 L 75 130 L 75 200 L 55 200 L 55 140 L 45 140 L 45 200 L 25 200 L 25 130 L 10 130 C 10 80 20 50 50 50 Z" fill="#1e293b" />
                      </symbol>
                    </defs>
                    
                    {/* Perspective Lines (The Tunnel) */}
                    <g stroke="#94a3b8" strokeWidth="2" strokeLinecap="round">
                      {/* Wall lines radiating to vanishing point approx at 450, 80 */}
                      <line x1="0" y1="0" x2="450" y2="80" />
                      <line x1="0" y1="80" x2="450" y2="80" />
                      <line x1="0" y1="200" x2="450" y2="80" />
                      <line x1="0" y1="350" x2="450" y2="80" />
                      <line x1="0" y1="400" x2="450" y2="80" />
                      
                      {/* Floor cross-lines for depth perception */}
                      <line x1="50" y1="380" x2="100" y2="280" strokeOpacity="0.3" /> 
                      <line x1="120" y1="350" x2="180" y2="220" strokeOpacity="0.3" />
                      <line x1="200" y1="320" x2="260" y2="180" strokeOpacity="0.3" />
                      <line x1="300" y1="280" x2="360" y2="140" strokeOpacity="0.3" />
                    </g>

                    {/* Figures - Identical scale, different positions */}
                    {/* Figure 1: Bottom Left (Closest) */}
                    <use href="#man-figure" x="50" y="180" width="80" height="160" />
                    
                    {/* Figure 2: Middle */}
                    <use href="#man-figure" x="190" y="125" width="80" height="160" />
                    
                    {/* Figure 3: Top Right (Furthest) */}
                    <use href="#man-figure" x="310" y="70" width="80" height="160" />
                    
                    <text x="250" y="380" textAnchor="middle" fontSize="12" fill="#94a3b8" fontStyle="italic">Všetky postavy sú identické (pixel-perfect)</text>
                 </svg>
                 <p className="text-xs text-slate-500 mt-2 italic text-center">
                    (Všetky tri postavy v tomto nákrese majú v skutočnosti úplne rovnakú veľkosť v pixeloch. Váš mozog tú vpravo hore vidí ako obra.)
                 </p>
            </div>
        </div>
      </div>
    )
  },
  heuristics: {
    title: "Heuristiky a Skreslenia (Heuristics & Biases)",
    icon: "fa-magnet",
    content: (
      <div className="space-y-12 text-lg text-slate-700 leading-relaxed animate-fade-in">
        <p>
          Heuristiky sú intuitívne skratky, ktoré používame na riešenie problémov. Väčšinou fungujú, ale vedú k systematickým chybám. Tu sú tri najdôležitejšie:
        </p>

        {/* 1. ANCHORING */}
        <div className="relative border-l-4 border-amber-500 pl-6 md:pl-10">
          <div className="absolute -left-3 top-0 w-6 h-6 bg-amber-500 rounded-full text-white flex items-center justify-center font-bold text-xs">1</div>
          <h4 className="font-bold text-slate-900 text-2xl mb-4">Efekt Ukotvenia (Anchoring)</h4>
          <p className="mb-4">
            Ľudia sa pri odhadoch "ukotvia" na akejkoľvek hodnote, ktorá je práve k dispozícii, aj keď je to úplný nezmysel.
          </p>
          <div className="bg-amber-50 p-6 rounded-xl shadow-sm">
            <strong className="block text-amber-900 mb-2">Experiment: Kolo šťastia</strong>
            <p className="text-sm text-slate-800">
              Tversky a Kahneman zmanipulovali koleso šťastia tak, aby padlo len na <strong>10</strong> alebo <strong>65</strong>.
              Potom sa účastníkov pýtali: <em>"Aké je percento afrických krajín v OSN?"</em>
              <br/><br/>
              Skupina s číslom 10 tipovala priemerne <strong>25%</strong>.<br/>
              Skupina s číslom 65 tipovala priemerne <strong>45%</strong>.<br/>
              Rozdiel 20% spôsobilo úplne náhodné číslo, o ktorom vedeli, že je náhodné.
            </p>
          </div>
          <p className="mt-4 text-sm font-bold text-slate-600">
            Aplikácia: V obchode zľava z "pôvodnej ceny 100€" na "50€" funguje, pretože 100€ slúži ako kotva, voči ktorej sa 50€ javí ako výhra.
          </p>
        </div>

        {/* 2. AVAILABILITY */}
        <div className="relative border-l-4 border-blue-500 pl-6 md:pl-10">
          <div className="absolute -left-3 top-0 w-6 h-6 bg-blue-500 rounded-full text-white flex items-center justify-center font-bold text-xs">2</div>
          <h4 className="font-bold text-slate-900 text-2xl mb-4">Heuristika dostupnosti (Availability)</h4>
          <p className="mb-4">
            Otázku <em>"Aká je frekvencia X?"</em> nahrádzame otázkou <em>"Ako ľahko si vybavím príklady X?"</em>.
            Preto sa bojíme vecí, ktoré sú mediálne známe (pády lietadiel), a podceňujeme časté riziká (cukrovka, astma).
          </p>
          <div className="bg-blue-50 p-6 rounded-xl shadow-sm">
            <strong className="block text-blue-900 mb-2">Experiment: Domáce práce</strong>
            <p className="text-sm text-slate-800">
              Výskumníci sa pýtali manželov: <em>"Akým percentom prispievate k domácim prácam?"</em>
              Keď sčítali odpovede oboch partnerov, výsledok bol vždy <strong>výrazne nad 100%</strong>.
              <br/><br/>
              Prečo? Lebo každý si ľahko vybaví svoje vlastné úsilie (vynášanie smetí, umývanie), ale ťažšie si vybavuje úsilie toho druhého. Nie je to egoizmus, je to chyba dostupnosti pamäte.
            </p>
          </div>
        </div>

        {/* 3. REPRESENTATIVENESS */}
        <div className="relative border-l-4 border-purple-500 pl-6 md:pl-10">
          <div className="absolute -left-3 top-0 w-6 h-6 bg-purple-500 rounded-full text-white flex items-center justify-center font-bold text-xs">3</div>
          <h4 className="font-bold text-slate-900 text-2xl mb-4">Reprezentatívnosť (Linda Problem)</h4>
          <p className="mb-4">
            Tendencia posudzovať pravdepodobnosť podľa toho, ako veľmi sa vec podobá na náš stereotyp, pričom ignorujeme logiku a štatistiku.
          </p>
          <div className="bg-purple-50 p-6 rounded-xl shadow-sm">
            <strong className="block text-purple-900 mb-2">Linda Problem</strong>
            <p className="text-sm text-slate-800 mb-4">
              Linda má 31 rokov, je slobodná, otvorená a veľmi inteligentná. Vyštudovala filozofiu. Ako študentka sa zaujímala o otázky diskriminácie a sociálnej spravodlivosti a zúčastnila sa protijadrových demonštrácií.
            </p>
            <p className="text-sm text-slate-800 font-bold mb-2">Ktorá možnosť je pravdepodobnejšia?</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>A) Linda je banková úradníčka.</li>
              <li>B) Linda je banková úradníčka a je aktívna vo feministickom hnutí.</li>
            </ul>
            <p className="text-sm text-slate-800 mt-4">
              Približne <strong>85% až 90%</strong> ľudí (vrátane štatistikov!) zvolí <strong>B</strong>.
              Prečo? Pretože B viac "sedí" na popis Lindy (stereotyp).
              <br/>
              <strong>Logická chyba:</strong> Podmnožina (bankárka + feministka) nemôže byť nikdy pravdepodobnejšia než celok (bankárka).
            </p>
          </div>
        </div>

      </div>
    )
  }
};

// --- NAVIGATION COMPONENTS ---

const Breadcrumbs = ({ onBack, activeTitle }: { onBack: () => void, activeTitle: string }) => (
  <div className="flex items-center gap-2 text-sm text-slate-500 mb-6 flex-wrap">
    <span onClick={onBack} className="cursor-pointer hover:text-blue-600 transition-colors">
      <i className="fa-solid fa-house"></i>
    </span>
    <i className="fa-solid fa-chevron-right text-xs text-slate-300"></i>
    <span onClick={onBack} className="cursor-pointer hover:text-blue-600 transition-colors">Pravidlá</span>
    <i className="fa-solid fa-chevron-right text-xs text-slate-300"></i>
    <span onClick={onBack} className="cursor-pointer hover:text-blue-600 transition-colors">Pravidlo #2</span>
    <i className="fa-solid fa-chevron-right text-xs text-slate-300"></i>
    <span className="text-blue-600 font-semibold truncate max-w-[150px] md:max-w-none">{activeTitle}</span>
  </div>
);

const Sidebar = ({ activeId, onSelect }: { activeId: string | null, onSelect: (id: string) => void }) => (
  <div className="w-full lg:w-72 flex-shrink-0 lg:sticky lg:top-24 h-fit space-y-2">
    <div className="p-4 bg-slate-100 rounded-xl mb-4 border border-slate-200">
      <h3 className="font-bold text-slate-700 text-sm uppercase tracking-wider mb-1">Koncepty</h3>
      <p className="text-xs text-slate-500">Thinking, Fast and Slow</p>
    </div>
    {Object.entries(kahnemanConcepts).map(([key, data]) => (
      <button
        key={key}
        onClick={() => onSelect(key)}
        className={`w-full text-left p-3 rounded-xl transition-all duration-200 flex items-center gap-3 text-sm ${
          activeId === key 
            ? 'bg-blue-600 text-white shadow-md font-medium' 
            : 'bg-white text-slate-600 hover:bg-slate-50 border border-transparent hover:border-slate-200'
        }`}
      >
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${activeId === key ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
          <i className={`fa-solid ${data.icon}`}></i>
        </div>
        <span className="truncate">{data.title.split('(')[0]}</span>
      </button>
    ))}
  </div>
);

// --- MAIN COMPONENT ---

interface RuleDetail {
  theory: string | React.ReactNode;
  steps: string[];
  script: {
    situation: string;
    you: string;
    them: string;
    result: string;
    isYouFirst?: boolean;
  };
}

interface Rule {
  id: number;
  title: string;
  subtitle: string;
  desc: string;
  practical: string;
  icon: string;
  details: RuleDetail;
}

export const JustListenView: React.FC<SectionProps> = ({ onBack, initialRuleId }) => {
  const [selectedRuleId, setSelectedRuleId] = useState<number | null>(null);
  const [activeConceptId, setActiveConceptId] = useState<string | null>(null);

  // Initialize with rule from props if available
  useEffect(() => {
    if (initialRuleId) {
      setSelectedRuleId(initialRuleId);
    }
  }, [initialRuleId]);

  // Scroll to top when entering detail view
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedRuleId, activeConceptId]);

  // SPECIAL REDIRECT FOR RULE #9 (TOXIC PEOPLE)
  if (selectedRuleId === 9) {
    return <ToxicPeopleView onBack={() => setSelectedRuleId(null)} />;
  }

  // RENDER CONCEPT DETAIL VIEW
  if (activeConceptId) {
    const concept = kahnemanConcepts[activeConceptId];
    return (
      <div className="min-h-screen bg-slate-50 pb-12">
        <div className="container mx-auto px-4 lg:px-8 pt-24 max-w-7xl">
          
          <Breadcrumbs 
            onBack={() => setActiveConceptId(null)} 
            activeTitle={concept.title.split('(')[0]} 
          />

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Navigation */}
            <Sidebar activeId={activeConceptId} onSelect={setActiveConceptId} />

            {/* Content Area */}
            <div className="flex-1">
              <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 animate-slide-up">
                 <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-8 md:p-12 relative overflow-hidden">
                   <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/4 -translate-y-1/4 pointer-events-none">
                     <i className={`fa-solid ${concept.icon} text-[15rem]`}></i>
                   </div>
                   <div className="relative z-10">
                     <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-blue-200 text-xs font-bold mb-4 uppercase tracking-widest">
                        <i className="fa-solid fa-brain"></i> Psychológia Mysle
                     </div>
                     <h2 className="text-2xl md:text-4xl font-extrabold mb-2 leading-tight">{concept.title}</h2>
                   </div>
                 </div>
                 
                 <div className="p-6 md:p-12">
                   {concept.content}
                 </div>

                 {/* Footer Navigation within concepts */}
                 <div className="bg-slate-50 p-6 border-t border-slate-100 flex justify-between items-center">
                    <button 
                      onClick={() => setActiveConceptId(null)}
                      className="text-slate-500 hover:text-blue-600 font-semibold text-sm flex items-center gap-2 transition-colors"
                    >
                      <i className="fa-solid fa-arrow-up"></i> Späť na prehľad
                    </button>
                    {/* Logic to find next concept could go here */}
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const rules: Rule[] = [
    {
      id: 1,
      title: "Najprv upokoj seba",
      subtitle: "Move Yourself from 'Oh F#@&' to OK",
      desc: "Ak je tvoja amygdala aktivovaná, aktivuje sa amygdala druhého človeka automaticky (cez zrkadlové neuróny). Racionálna komunikácia neexistuje. Musíš sa dostať cez seba, až potom sa môžeš dostať k druhému.",
      practical: "Identifikuj svoje pocity a vedome ich pomenuj. Už samotné pomenovanie znižuje aktiváciu amygdaly. Povedz si: 'Cítim hnev'. Dýchaj.",
      icon: "fa-person-praying",
      details: {
        theory: "„Oh F#@&“ nie je nadávka – je to neurologický stav. Je to moment, keď cítiš tlak, frustráciu, hnev alebo strach. V tomto stave funguje Systém 1 (rýchly, emočný, obranný) a Systém 2 je offline. Slová, argumenty a logika nepreniknú. Ak sa neupokojíš, klient bude reagovať na tvoj emočný stav, nie na tvoj obsah. Odpor vznikne ešte pred prvou vetou. Najprv musíš prejsť zo stavu, v ktorom si fixovaný na to, aký by svet mal byť, do stavu, v ktorom si pripravený riešiť svet taký, aký je.",
        steps: [
          "1. Fáza REAKCIE („Oh F#@&“ - Je to v prdeli): Priznaj si: „Toto je katastrofa, som v koncoch.“ Nesnaž sa to racionalizovať ani potlačiť. Zastav sa. Ak sa dá, zatvor na minútu oči.",
          "2. Fáza UVOĽNENIA („Do kelu“): Priznaj chaos: „Toto musím odpratať, takéto veci sa mi dejú vždy.“ Dýchaj zhlboka nosom. Pomenuj emóciu: „Som naštvaný/vydesený.“ Nechaj to odísť.",
          "3. Fáza VYCENTROVANIA („Och“): „Dobre, viem to dať do poriadku, ale nebude to príjemné.“ Pokračuj v dýchaní. S každým nádychom klesaj zo stavu pohotovosti.",
          "4. Fáza ZAMERANIA („Čo už“): „Nedovolím, aby mi to zničilo deň/kariéru/vzťah.“ Presuň pozornosť na to, čo musíš urobiť hneď teraz na obmedzenie škôd.",
          "5. Fáza ZAPOJENIA („OK“): „Je to dobré. Som pripravený to vyriešiť.“ Otvor oči. Teraz (a až teraz) konaj."
        ],
        script: {
          situation: "Klient na vás kričí do telefónu a vy cítite nával paniky a hnevu.",
          them: "Vy ste to úplne pokazili! Okamžite to chcem mať na stole!",
          you: "(V duchu - Oh F#@&): Do riti, to je koniec, kričí na mňa... (Do kelu): Cítim, ako mi búši srdce, chcem na neho nahučať. (Nádych - Och): Dobre, je to zlé, ale neumieram. (Čo už): Musím ho upokojiť, inak prídem o kontrakt. (OK): Idem na to.",
          result: "Namiesto protiútoku (amygdala vs amygdala) odpovedáte pokojne, pretože ste vypli svoj vnútorný poplach a nenechali ste sa strhnúť.",
          isYouFirst: false
        }
      }
    },
    {
      id: 2,
      title: "Preprogramuj sa na počúvanie",
      subtitle: "Rewire Yourself to Listen",
      desc: "Vypnite vnútorný monológ. Väčšina ľudí nepočúva, len čaká na pauzu, aby mohla hovoriť. Mozog vkladá filtre, ktoré musíte vedome obísť.",
      practical: "Hrajte sa na detektíva. Vašou úlohou nie je predať, ale zistiť, 'kto je tento človek'. Vzdajte sa potreby reagovať.",
      icon: "fa-ear-listen",
      details: {
        theory: (
          <div className="space-y-8 text-sm md:text-base leading-relaxed">
            <div>
              <p className="mb-4">
                Väčšina ľudí nepočúva, aj keď si myslí, že áno. Dôvod nie je v zlej vôli ani v nedostatku empatie, ale v <strong>automatickom fungovaní mozgu (Systém 1)</strong>. Počujeme, ale nepočúvame, pretože mozog medzi vstupom a porozumením vkladá <strong>filtre</strong>: predpoklady, nálepky, minulé skúsenosti a rýchle hodnotenia. Čím je filter silnejší, tým menej počúvame.
              </p>
              <div className="bg-yellow-50 p-4 border-l-4 border-yellow-400 text-slate-700 italic text-sm mb-6">
                "Nepočúvaš vstup, ale reaguješ na to, čo je už v tvojej hlave."
              </div>
            </div>

            {/* Clickable Cards for Concepts */}
            <div className="grid gap-6">
                
                <div 
                  onClick={() => setActiveConceptId('associative')}
                  className="bg-slate-50 p-6 rounded-2xl border border-slate-200 cursor-pointer group hover:bg-blue-50 hover:border-blue-200 transition-all shadow-sm hover:shadow-md"
                >
                  <h4 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-3 group-hover:text-blue-700">
                    <i className="fa-solid fa-share-nodes text-blue-500"></i> 
                    Asociačný stroj (The Associative Machine)
                    <i className="fa-solid fa-arrow-right ml-auto text-slate-300 group-hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1"></i>
                  </h4>
                  <p className="text-sm text-slate-600">
                    Prečo okamžite reagujete na spojenie slov "Banány" a "Zvracanie"? Ako mozog vytvára koherentný príbeh z ničoho.
                  </p>
                </div>

                <div 
                  onClick={() => setActiveConceptId('ease')}
                  className="bg-slate-50 p-6 rounded-2xl border border-slate-200 cursor-pointer group hover:bg-green-50 hover:border-green-200 transition-all shadow-sm hover:shadow-md"
                >
                  <h4 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-3 group-hover:text-green-700">
                    <i className="fa-solid fa-feather text-green-500"></i> 
                    Kognitívna plynulosť (Cognitive Ease)
                    <i className="fa-solid fa-arrow-right ml-auto text-slate-300 group-hover:text-green-500 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1"></i>
                  </h4>
                  <p className="text-sm text-slate-600">
                    Prečo veríme veciam, ktoré sú napísané jasným písmom, a prečo je dobrá nálada znakom bezpečia.
                  </p>
                </div>

                <div 
                  onClick={() => setActiveConceptId('wysiati')}
                  className="bg-slate-50 p-6 rounded-2xl border border-slate-200 cursor-pointer group hover:bg-indigo-50 hover:border-indigo-200 transition-all shadow-sm hover:shadow-md"
                >
                  <h4 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-3 group-hover:text-indigo-700">
                    <i className="fa-solid fa-eye-slash text-indigo-500"></i> 
                    WYSIATI (Skákanie k záverom)
                    <i className="fa-solid fa-arrow-right ml-auto text-slate-300 group-hover:text-indigo-500 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1"></i>
                  </h4>
                  <p className="text-sm text-slate-600">
                    "What You See Is All There Is". Prečo ignorujeme chýbajúce informácie a prečo je koherencia dôležitejšia než pravda.
                  </p>
                </div>

                <div 
                  onClick={() => setActiveConceptId('substitution')}
                  className="bg-slate-50 p-6 rounded-2xl border border-slate-200 cursor-pointer group hover:bg-red-50 hover:border-red-200 transition-all shadow-sm hover:shadow-md"
                >
                  <h4 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-3 group-hover:text-red-700">
                    <i className="fa-solid fa-arrows-rotate text-red-500"></i> 
                    Substitúcia otázok
                    <i className="fa-solid fa-arrow-right ml-auto text-slate-300 group-hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1"></i>
                  </h4>
                  <p className="text-sm text-slate-600">
                    Keď je otázka príliš ťažká, odpovieme na ľahšiu bez toho, aby sme si to všimli. (Julie a čítanie v 4 rokoch).
                  </p>
                </div>

                <div 
                  onClick={() => setActiveConceptId('heuristics')}
                  className="bg-slate-50 p-6 rounded-2xl border border-slate-200 cursor-pointer group hover:bg-amber-50 hover:border-amber-200 transition-all shadow-sm hover:shadow-md"
                >
                  <h4 className="font-bold text-slate-800 text-lg mb-2 flex items-center gap-3 group-hover:text-amber-700">
                    <i className="fa-solid fa-magnet text-amber-500"></i> 
                    Heuristiky a Skreslenia
                    <i className="fa-solid fa-arrow-right ml-auto text-slate-300 group-hover:text-amber-500 opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1"></i>
                  </h4>
                  <p className="text-sm text-slate-600">
                    Ukotvenie, Dostupnosť, Linda problém. Mentálne skratky, ktoré nás klamú.
                  </p>
                </div>

            </div>
          </div>
        ),
        steps: [
          "1. Uvedom si filtre: Priznaj si, že tvoj mozog práve teraz skáče k záverom a dopĺňa si chýbajúce info.",
          "2. Vzdaj sa potreby reagovať: Vedome spomaľ. Tvojím cieľom nie je odpovedať, ale chápať.",
          "3. Hľadaj neplynulosť: Ak ti niečo 'nesedí' alebo to vyžaduje námahu počúvať, práve tam je pravda. Nepočúvaj len to, čo potvrdzuje tvoj názor.",
          "4. Prekonaj WYSIATI: Pýtaj sa sám seba: 'Čo nevidím? Čo mi tento človek nepovedal?'"
        ],
        script: {
          situation: "Klient hovorí niečo, čo odporuje vášmu názoru alebo skúsenosti.",
          you: "(V duchu): Cítim odpor. Chcem ho opraviť. (Stop): To je moja kognitívna neplynulosť. (Nahlas): To je zaujímavý pohľad, ktorý som nezvažoval. Povedzte mi o tom viac, prečo to vidíte práve takto?",
          them: "Lebo moja skúsenosť z minula je...",
          result: "Namiesto hádky o názoroch získavate dáta, ktoré by ste inak prepočuli kvôli filtrom.",
          isYouFirst: true
        }
      }
    },
    {
      id: 3,
      title: "Daj pocit, že je 'cítený'",
      subtitle: "Make the Other Person Feel 'Felt'",
      desc: "Toto je najsilnejší nástroj. Nestačí rozumieť slovám, musíte presne pomenovať emóciu druhého.",
      practical: "Povedzte: 'Mám pocit, že si z toho naozaj frustrovaný a cítiš, že ťa nikto nepočúva. Je to tak?'",
      icon: "fa-heart",
      details: {
        theory: (
          <div className="space-y-6">
            <div className="bg-purple-50 p-6 rounded-xl border-l-4 border-purple-500 italic text-slate-700">
              "Sebarealizujúci sa ľudia majú hlboký pocit identifikácie, sympatie a náklonnosti k ľudským bytostiam všeobecne. Cítia príbuznosť a spojenie, akoby všetci ľudia boli členmi jednej rodiny." — Abraham Maslow
            </div>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Príbeh: Hank a Audrey</h4>
            <p className="text-slate-700">
              Hank a Audrey boli partneri v právnickej firme, ktorí sa neznášali. Audrey bola "dažďomaker" (nosila biznis), Hank bol tichý právnik. Neustále sa hádali.
              <br/><br/>
              Zlom nastal, keď sa mediátor spýtal Hanka: <span className="font-bold text-purple-700">"Vieš o tom, že Audrey má pocit, že ju považuješ za úplne odpudzujúcu a nechutnú?"</span>
              <br/><br/>
              Audrey sa rozplakala. Hank bol šokovaný a okamžite zjemnil: "Nie, to nie je pravda! Len ma niekedy vytáčaš." V tom momente Audrey <strong>pocítila, že je cítená</strong>. Konflikt sa zmenil na spoluprácu.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Prečo to funguje? (Zrkadlové neuróny)</h4>
            <p className="text-slate-700">
              Keď presne pomenujete emóciu druhého ("Cítiš sa osamelý..."), aktivujete jeho zrkadlové neuróny. Jeho mozog zaznamená: "Tento človek mi rozumie." Biologickou reakciou je vďačnosť a túžba rozumieť vám na oplátku. Je to neodolateľný ťah.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Strach z chyby</h4>
            <p className="text-slate-700">
              V biznise je to kľúčové. Sebavedomí manažéri sa často boja urobiť chybu viac, než chcú urobiť správnu vec. Ak tento strach pomenujete ("Mám pocit, že sa bojíte, že ak to nevyjde, padne to na vašu hlavu"), okamžite si získate ich dôveru.
            </p>
          </div>
        ),
        steps: [
          "Pripojte sa k emócii: Identifikujte, čo ten človek cíti (hnev, frustráciu, strach).",
          "Povedzte: 'Snažím sa pochopiť, čo prežívaš, a mám pocit, že si... (doplň emóciu). Je to tak?'",
          "Ventilácia: 'Ako veľmi ťa to hnevá?' (Nechajte ich hovoriť).",
          "Príčina: 'A dôvodom, prečo si taký nahnevaný, je...?'",
          "Úľava: 'Čo sa musí stať, aby si sa cítil lepšie?'",
          "Spolupráca: 'Čo môžem urobiť ja, aby sa to stalo?'"
        ],
        script: {
          situation: "Zamestnankyňa (Debbie) sa zdráha prijať nový projekt a hľadá výhovorky.",
          you: "Debbie, snažím sa nasať atmosféru a mám pocit, že sa trochu bojíš ísť do niečoho takého nového. Možno sa dokonca bojíš veľmi. Je to tak?",
          them: "(Vydýchne) Bála som sa to povedať, ale... nie som expert na grafiku a doma je to teraz šialené...",
          result: "Debbie prechádza z odporu do úľavy. Teraz môžete riešiť konkrétnu pomoc (školenie), nie jej 'výhovorky'.",
          isYouFirst: true
        }
      }
    },
    {
      id: 4,
      title: "Buď viac zvedavý než zaujímavý",
      subtitle: "Be More Interested Than Interesting",
      desc: "Snaha zapôsobiť často pôsobí arogantne. Úprimný záujem o druhého otvára dvere, ktoré logika neotvorí.",
      practical: "Pýtajte sa otvorené otázky: 'Ako ste sa dostali k tomu, čo robíte?'",
      icon: "fa-magnifying-glass",
      details: {
        theory: (
          <div className="space-y-6">
            <div className="bg-indigo-50 p-6 rounded-xl border-l-4 border-indigo-500 italic text-slate-700">
              "Nuda vzniká vtedy, keď sa mi nepodarí urobiť druhého človeka zaujímavým." — Warren Bennis
            </div>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Tenisový zápas vs. Detektívna hra</h4>
            <p className="text-slate-700">
              Väčšina konverzácií prebieha ako tenis. Oni odpália loptičku (povedia príbeh), vy odpálite späť (váš príbeh).
              <em>"Ja som bol v Ríme." -> "Á, ja som bol v Paríži!"</em>
              <br/>
              Toto je chyba. Skutoční majstri komunikácie (ako Warren Bennis alebo Jim Collins) hrajú <strong>detektívnu hru</strong>. Ich cieľom nie je "vyhrať" výmenu, ale zistiť o druhom čo najviac.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Biologický hlad (Mirror Neuron Deficit)</h4>
            <p className="text-slate-700">
              Čím viac sa zaujímate o druhého, tým viac sýtiate jeho "zrkadlové neuróny". Ľudia majú biologický hlad po tom, aby boli vnímaní. Ak tento hlad nasýtite, začnú sa o vás zaujímať späť.
              <br/>
              <strong>Pravidlo "Interesting Jackass":</strong> Ľudia, ktorí posielajú vianočné pozdravy plné vlastných úspechov (dovolenky, povýšenia), sú otravní. Ľudia, ktorí sa v pozdrave pýtajú na VÁS, sú tí, s ktorými chcete ísť na obed.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Technika F-T-D (Feel, Think, Do)</h4>
            <p className="text-slate-700">
              Aby sa človek cítil "poznaný", musíte sa pýtať otázky, ktoré odhalia tri vrstvy:
              <ul className="list-disc list-inside mt-2 ml-4">
                <li><strong>Feel:</strong> Čo cítili?</li>
                <li><strong>Think:</strong> Čo si o tom mysleli?</li>
                <li><strong>Do:</strong> Čo urobili (alebo by urobili)?</li>
              </ul>
            </p>
          </div>
        ),
        steps: [
          "Prestaňte byť 'zaujímavý': Nesnažte sa zapôsobiť. Tým len súťažíte o status.",
          "Buďte detektív: Prijmite fakt, že každý človek má v sebe úžasný príbeh. Vašou úlohou je ho nájsť.",
          "Pýtajte sa 'Deepeners': 'Ako ste sa dostali k tomu, čo robíte?' (Najlepšia otváracia otázka podľa Jeffa Kichavena).",
          "Nechajte ich vydýchnuť: Keď skončia príbeh, nezačnite hovoriť o sebe. Spýtajte sa: 'A čo bolo potom?'",
          "FTD otázky: Pýtajte sa na emócie, myšlienky a činy, nie len na fakty."
        ],
        script: {
          situation: "Ste na večierku/konferencii a stretnete dôležitého človeka (napr. CEO), ktorý vyzerá znudene.",
          you: "Pán Stemberg, keby ste to mohli urobiť znova, čo je jedna vec, ktorá by vám ušetrila najviac problémov v kariére?",
          them: "(Ožije, pretože dostal otázku, ktorú CHCE zodpovedať): Fú, to je dobrá otázka. Asi by som čakal dlhšie s investormi...",
          result: "Zmenili ste sa z 'tváre v dave' na zaujímavého partnera, pretože ste mu dali šancu byť zaujímavým.",
          isYouFirst: true
        }
      }
    },
    {
      id: 5,
      title: "Daj ľuďom pocit hodnoty",
      subtitle: "Make People Feel Valuable",
      desc: "Každý človek bojuje o pocit dôležitosti. Ak im ho dáte, stanú sa vašimi spojencami.",
      practical: "Stratégia 'Vianočná večera': Dajte otravným príbuzným dôležitú úlohu (napr. vítať hostí). Zmeníte ich z kritikov na spojencov.",
      icon: "fa-gem",
      details: {
        theory: (
          <div className="space-y-6">
            <div className="bg-amber-50 p-6 rounded-xl border-l-4 border-amber-500 italic text-slate-700">
              "Každý má na krku neviditeľnú ceduľku: 'Daj mi pocit, že som dôležitý'." — Mary Kay Ash
            </div>

            <p className="text-slate-700 mt-4">
              Toto pravidlo ide hlbšie než len "byť vypočutý". Je to o existenciálnej validácii. Znamená to povedať človeku: <em>"Máš dôvod tu byť. Tvoja existencia má zmysel."</em>
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Prečo sú ľudia otravní? (Graffiti Rule)</h4>
            <p className="text-slate-700">
              Väčšina "problémových" ľudí (sťažovatelia, prerušovači) trpí deficitom dôležitosti. Sú ako graffiti umelci: Ak nevedia získať pozornosť a uznanie pozitívnym spôsobom, vynútia si ju negatívnym spôsobom (sťažovaním sa, robením problémov). Sú hladní po uznaní.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Príbeh: Anita a Janet</h4>
            <p className="text-slate-700">
              Anita bola kolegyňa, ktorá neustále vtrhla do kancelárie manažérky Janet a sťažovala sa na banality. Janet to trpela. Goulston poradil Janet iný prístup:
              Namiesto vyhodenia ju uznala: <em>"Anita, to čo hovoríš, je príliš dôležité na to, aby som ťa počúvala len na pol ucha."</em> A potom jej dala úlohu: <em>"Príď o 2 hodiny, keď budem mať čas, ale prines aj návrh riešenia."</em>
              Anita sa už nevrátila, pretože jej cieľom bola pozornosť, nie riešenie problému.
            </p>
          </div>
        ),
        steps: [
          "Identifikujte 'otravných' ľudí: Uvedomte si, že ich správanie je volaním o pozornosť.",
          "Dajte im dôležitosť (proaktívne): Nečakajte, kým si ju vynútia. Povedzte im: 'Tvoj príspevok je pre nás kľúčový.'",
          "Delegujte zodpovednosť: Dajte im úlohu, vďaka ktorej sa budú cítiť potrební (napr. 'Prosím, postarajte sa o nových hostí').",
          "Podmienečná pozornosť: Pre sťažovateľov - 'Vypočujem ťa, ale musíš prísť s návrhom riešenia'."
        ],
        script: {
          situation: "Kolegyňa (Anita) vtrhne do kancelárie a sťažuje sa na maličkosti, čím mrhá vaším časom.",
          you: "Anita, to čo hovoríš, je príliš dôležité na to, aby som ti venoval len polovicu pozornosti. Teraz dokončujem niečo kritické. Príď za mnou o 14:00, dám ti plných 5 minút. Dovtedy si prosím priprav návrh riešenia, ktorý je realizovateľný.",
          them: "Ehm... dobre. (Odchádza a pravdepodobne sa už nevráti, alebo príde pripravená).",
          result: "Dali ste jej pocit hodnoty (brali ste ju vážne), ale zároveň ste nastavili hranicu a zodpovednosť.",
          isYouFirst: true
        }
      }
    },
    {
      id: 6,
      title: "Pomôž ľuďom 'vydýchnuť'",
      subtitle: "Help People to Exhale",
      desc: "Keď je človek v strese, mentálne 'zadržiava dych' alebo ventiluje. Skutočná úľava prichádza až po výdychu, ktorý im musíte umožniť vy.",
      practical: "Po tom, čo sa vyrozprávajú, urobte pauzu a povedzte: 'Povedz mi o tom viac.'",
      icon: "fa-wind",
      details: {
        theory: (
          <div className="space-y-6">
            <div className="bg-teal-50 p-6 rounded-xl border-l-4 border-teal-500 italic text-slate-700">
              "Niekedy je najdôležitejšou vecou celého dňa odpočinok, ktorý si doprajeme medzi dvoma hlbokými nádychmi." — Etty Hillesum
            </div>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Distres vs. Exhale (Príbeh Alexa)</h4>
            <p className="text-slate-700">
              Vystresovaný manažér Alex ventiloval 15 minút. Goulston ho zastavil: <em>"Počúvaj to ticho."</em>
              Alex nechápal. Goulston: <em>"Ticho sa nachádza medzi hlukom v tvojej hlave a hlukom v tvojom živote. Zatvor oči a dýchaj."</em>
              Alex sa rozplakal. Konečne vydýchol. Ventilácia je len vypúšťanie pary (často agresívne), <strong>Exhale (výdych)</strong> je uvoľnenie napätia, ktoré otvára myseľ.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Príbeh: Onkologický pacient (Mr. Williams)</h4>
            <p className="text-slate-700">
              Mr. Williams, onkologický pacient, predtým vyhodil z izby dvoch psychiatrov. Goulston si preto vymenil menovku za "Onkológia" a vošiel dnu. Pacient naňho zízal plný hnevu. Goulston neuhol pohľadom a spýtal sa priamo:
              <br/>
              <span className="font-bold text-teal-700">"Aké neznesiteľné to je vo vašom vnútri?"</span>
              <br/>
              Pacient odvrkol: <em>"To nechcete vedieť!"</em>
              <br/>
              Goulston: <em>"Asi máte pravdu, nechcem. Ale ak o tom nebude vedieť nikto iný okrem vás, zošaliete z toho."</em>
              <br/>
              Pacient sa usmial: <em>"Už som tam (už som zošalel). Sadnite si."</em>
              <br/>
              Tým, že Goulston ustál jeho pohľad a išiel priamo k podstate bolesti, umožnil mu skutočne vydýchnuť.
            </p>
          </div>
        ),
        steps: [
          "Všímajte si reč tela: Prekrížené ruky často signalizujú 'prekríženú' a uzavretú myseľ.",
          "Nechajte ich ventilovať: Neskáčte do reči, nebráňte sa, neponúkajte riešenia. Iba počúvajte.",
          "Pauza (Kľúčový moment): Keď prestanú hovoriť, ostaňte ticho. Nezačnite hneď rozprávať.",
          "Magická fráza: Povedzte 'Povedzte mi o tom viac' (Tell me more).",
          "Pre deti a tínedžerov: Opýtajte sa: 'Kedy si sa na mňa najviac hneval? Čo si mal chuť vtedy urobiť?'"
        ],
        script: {
          situation: "Šéf (alebo partner) na vás 5 minút kričal kvôli chybe a práve sa zastavil, aby sa nadýchol.",
          you: "(Po krátkej pauze, pokojným hlasom): Povedzte mi o tom viac.",
          them: "(Zaskočený, že sa nebránite, vydýchne): No... ide o to, že mám obrovský tlak zhora a keď sa stane toto, vyzerám ako idiot...",
          result: "Partner prechádza z agresívnej ventilácie do vysvetľovania skutočného problému (strach o reputáciu).",
          isYouFirst: true
        }
      }
    },
    {
      id: 7,
      title: "Odlož kognitívnu disonanciu",
      subtitle: "Check Your Dissonance at the Door",
      desc: "Ak si myslíte, že ste nápomocný, ale druhí vás vnímajú ako otravného, vzniká nesúlad. Tento nesúlad bráni empatii a vyvoláva v ľuďoch pocit ohrozenia.",
      practical: "Opýtajte sa: 'Mám pocit, že vás teraz možno trochu tlačím. Vnímate to tak?' Priznanie možného nesúladu okamžite znižuje napätie.",
      icon: "fa-door-open",
      details: {
        theory: (
          <div className="space-y-6">
            <div className="bg-indigo-50 p-6 rounded-xl border-l-4 border-indigo-500 italic text-slate-700">
              "Najúspešnejší ľudia sú tí, ktorí nemajú žiadne ilúzie o tom, kým sú." — Bud Bray
            </div>

            <p className="text-slate-700 text-lg leading-relaxed">
              <strong>Kognitívna disonancia</strong> v komunikácii nastáva, keď existuje priepasť medzi tým, ako si myslíte, že pôsobíte (Váš zámer), a tým, ako vás v skutočnosti vnímajú druhí (Ich vnímanie).
              <br/><br/>
              Napríklad:
            </p>

            {/* Dissonance Table based on text */}
            <div className="grid md:grid-cols-2 gap-4 my-6">
              <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Vy si myslíte, že ste:</div>
                <div className="font-bold text-green-600 text-lg">Bystrý / Šikovný</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-2 mb-1">Oni vás vidia ako:</div>
                <div className="font-bold text-red-500 text-lg">Prefíkaného (Sly)</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Vy si myslíte, že ste:</div>
                <div className="font-bold text-green-600 text-lg">Sebavedomý</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-2 mb-1">Oni vás vidia ako:</div>
                <div className="font-bold text-red-500 text-lg">Arogantného</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Vy si myslíte, že ste:</div>
                <div className="font-bold text-green-600 text-lg">Vášnivý</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-2 mb-1">Oni vás vidia ako:</div>
                <div className="font-bold text-red-500 text-lg">Impulzívneho / "Too much"</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Vy si myslíte, že ste:</div>
                <div className="font-bold text-green-600 text-lg">Detailista</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-2 mb-1">Oni vás vidia ako:</div>
                <div className="font-bold text-red-500 text-lg">Hnidopicha (Nitpicking)</div>
              </div>
            </div>

            <p className="text-slate-700">
              Tento nesúlad spôsobuje, že ľudia sa prestanú pýtať <em>"Čo pre mňa môže tento človek urobiť?"</em> a začnú sa báť <em>"Čo mi tento človek plánuje urobiť?"</em>. Blokuje to empatiu a vytvára odpor.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Príbeh: Jack, daňový právnik</h4>
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
              <p className="text-slate-700 mb-4">
                Jack bol skvelý daňový právnik – tichý, slušný, extrémne pripravený. Napriek tomu strácal klientov v prospech menej schopných kolegov. Prečo?
                <br/><br/>
                Goulston mu to vysvetlil: <em>"Keď si ľudia najímajú právnika proti daňovému úradu (IRS), podvedome chcú najať <strong>Gladiátora</strong>. Chcú vedieť, že dokážete zabíjať."</em> Jack ale pôsobil príliš jemne. Vznikla disonancia medzi ich potrebou (ochranca) a jeho prejavom (slušák).
              </p>
              <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                <strong className="block text-blue-900 mb-2">Riešenie (Pre-emptive Defusing):</strong>
                <p className="text-slate-600 text-sm">
                  Jack začal klientom hovoriť vopred:
                  <br/><br/>
                  <span className="italic text-slate-800 font-medium">
                    "Mimochodom, ak si ma najmete proti daňovému úradu, musíte vedieť, že v príprave som 'zabijak', ale nie som 'vrah'. Zničím argumenty protistrany dôkladnou prípravou, ale nevyžívam sa v ničení ľudí."
                  </span>
                </p>
              </div>
              <p className="text-slate-700 mt-4 text-sm">
                Tým, že pomenoval tento nesúlad ("vyzerám jemne, ale konám tvrdo"), disonancia zmizla a klienti mu začali dôverovať.
              </p>
            </div>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Paradox Hádky: Robert a Susan</h4>
            <p className="text-slate-700">
              Disonancia je častým vinníkom hádok. Robert a Susan sa hádali (o meškaní na večeru vs. kontrole).
              Keď sa ich Goulston opýtal, čo robia, obaja povedali: <em>"Ja sa bránim, lebo na mňa útočí."</em>
              <br/><br/>
              <strong className="text-red-600">Kľúčové zistenie:</strong> Ľudia sa správajú najagresívnejšie vtedy, keď sa cítia bezmocní a zahnaní do kúta. Vyzerajú ako útočníci, ale vnútorne sa cítia ako obete, ktoré sa bránia. Ak si myslíte "on útočí", ale on si myslí "ja sa bránim", nikdy sa nepochopíte.
            </p>

            <h4 className="font-bold text-slate-900 text-xl mt-4">Technika: Feedforward (Dopredná spätná väzba)</h4>
            <div className="bg-emerald-50 p-6 rounded-xl border border-emerald-200">
              <p className="text-slate-700 mb-4">
                Ako zistiť, ako vás vnímajú iní, bez toho, aby ste sa urazili? Marshall Goldsmith vymyslel techniku, ktorá sa nezameriava na minulé chyby (kritika), ale na budúce riešenia.
              </p>
              <ul className="list-disc list-inside text-emerald-900 text-sm space-y-2">
                <li>Vyberte si správanie, ktoré chcete zlepšiť (napr. "chcem lepšie prijímať kritiku").</li>
                <li>Opýtajte sa kolegu/partnera: <strong>"Aké sú dve veci, ktoré môžem v budúcnosti urobiť inak, aby sa nám lepšie spolupracovalo?"</strong></li>
                <li>Vypočujte si návrhy.</li>
                <li>Povedzte jediné slovo: <strong>"Ďakujem"</strong>. (Žiadne "Ale...", žiadne "To som tak nemyslel").</li>
              </ul>
            </div>
          </div>
        ),
        steps: [
          "Realitný test (Opýtajte sa expertov): Nájdite 3 úprimných ľudí a opýtajte sa: 'Aké sú 3 vlastnosti, ktorými leziem ľuďom na nervy?' (Dajte im zoznam: arogantný, zbrklý, pasívny, hnidopich...). Ak sa zhodnú, je to pravda.",
          "Feedforward: Namiesto pýtania sa 'Čo som urobil zle?' sa pýtajte 'Čo môžem nabudúce urobiť lepšie?'. Poďakujte a nebráňte sa.",
          "Preventívne odistenie (Jackova metóda): Ak viete, že pôsobíte inak, než aký ste (napr. vyzeráte prísne, ale ste len sústredený), povedzte to vopred: 'Možno sa budem tváriť zamračene, ale to len preto, že premýšľam, nie že som nahnevaný.'",
          "V hádke zastavte cyklus: Povedzte: 'Mám pocit, že ja sa bránim a ty sa brániš. Poďme začať znova s tým, že si nechceme ublížiť.'"
        ],
        script: {
          situation: "Vysvetľujete niečo tínedžerovi, ktorý pozerá do mobilu.",
          you: "Mám pocit, že ti zniem ako pokazená platňa a že všetko, čo hovorím, je pre teba len otravné poučovanie. Je to tak?",
          them: "(Zdvihne zrak) Trochu hej.",
          result: "Úprimnosť prelomila bariéru. Teraz môžete zmeniť tón na partnerský.",
          isYouFirst: true
        }
      }
    },
    {
      id: 8,
      title: "Odkry krk",
      subtitle: "Bare Your Neck",
      desc: "Zvieratá si odkrývajú krk na znak podriadenosti, aby zastavili útok. U ľudí funguje priznanie strachu alebo chyby podobne. Odzbrojuje.",
      practical: "Keď ste zahnaní do kúta: 'Úprimne, bojím sa. Neviem, čo mám povedať, aby som to nezhoršil. Môžeš mi pomôcť?'",
      icon: "fa-user-shield",
      details: {
        theory: (
          <div className="space-y-4">
            <p>
              Keď sa bránite, druhý útočí. Keď útočíte, druhý sa bráni.
              Ak odhalíte zraniteľnosť ("Odkryjete krk"), prerušíte tento cyklus.
              Druhú stranu to šokuje a prepne ich z módu "nepriateľ" do módu "ochranca" alebo aspoň "človek".
            </p>
          </div>
        ),
        steps: [
          "Použite to len vtedy, keď nemáte čo stratiť.",
          "Priznajte pocity, nie fakty: 'Cítim sa bezmocne', nie 'Som neschopný'.",
          "Požiadajte o pomoc."
        ],
        script: {
          situation: "Urobili ste chybu v prezentácii pre šéfa a on sa chystá kričať.",
          you: "Šéfe, skôr než začneš – túto časť som totálne podcenil. Je mi to ľúto a bojím sa, že to ohrozí projekt. Potrebujem tvoj pohľad, ako to zachrániť.",
          them: "No... (zmierni tón). Dobre, že si to povedal. Pozrieme sa na to.",
          result: "Šéf prechádza z módu 'sudca' do módu 'mentor'.",
          isYouFirst: true
        }
      }
    },
    {
      id: 9,
      title: "Vyhýbaj sa toxickým ľuďom",
      subtitle: "Steer Clear of Toxic People",
      desc: "Niektorí ľudia nechcú riešenie. Chcú konflikt. S týmito ľuďmi pravidlá nefungujú. Musíte sa chrániť.",
      practical: "Kliknite pre otvorenie modulu o toxických osobnostiach (Needy, Bully, Narcissist, Psychopath).",
      icon: "fa-biohazard",
      details: undefined // Handled by ToxicPeopleView
    }
  ];

  const handleCardClick = (id: number) => {
    setSelectedRuleId(id);
  };

  const selectedRule = rules.find(r => r.id === selectedRuleId);

  // RENDER DETAIL VIEW
  if (selectedRule) {
    return (
      <div className="container mx-auto px-6 pt-24 pb-12 animate-fade-in max-w-5xl">
        <button 
          onClick={() => setSelectedRuleId(null)}
          className="mb-8 flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors group"
        >
          <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-50">
            <i className="fa-solid fa-arrow-left"></i>
          </div>
          Späť na prehľad pravidiel
        </button>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
          {/* Header */}
          <div className="bg-slate-900 text-white p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-10 -mt-10 opacity-10">
              <i className={`fa-solid ${selectedRule.icon} text-[15rem]`}></i>
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-4">
                <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase">Pravidlo #{selectedRule.id}</span>
                <span className="text-blue-200 font-medium tracking-wide text-sm uppercase">{selectedRule.subtitle}</span>
              </div>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">{selectedRule.title}</h2>
              <p className="text-xl text-slate-300 max-w-3xl font-light leading-relaxed">
                {selectedRule.desc}
              </p>
            </div>
          </div>

          <div className="p-8 md:p-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column: Theory & Steps */}
            <div className="lg:col-span-2 space-y-10">
              <section>
                <h3 className="flex items-center gap-3 text-2xl font-bold text-slate-800 mb-4">
                  <i className="fa-solid fa-book-open text-blue-500"></i>
                  Teória a Kontext
                </h3>
                <div className="text-slate-600 leading-relaxed text-lg text-justify">
                  {selectedRule.details.theory}
                </div>
              </section>

              <section>
                <h3 className="flex items-center gap-3 text-2xl font-bold text-slate-800 mb-6">
                  <i className="fa-solid fa-list-check text-green-500"></i>
                  Ako na to (Kroky)
                </h3>
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
                  <ul className="space-y-4">
                    {selectedRule.details.steps.map((step, idx) => (
                      <li key={idx} className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-white border-2 border-green-500 flex items-center justify-center flex-shrink-0 font-bold text-green-600 text-sm">
                          {idx + 1}
                        </div>
                        <p className="text-slate-700 font-medium pt-1">{step}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </section>
            </div>

            {/* Right Column: Script & Practical */}
            <div className="space-y-8">
              {selectedRule.details.script && (
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                <h3 className="font-bold text-blue-900 mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-comments"></i> Modelový scenár
                </h3>
                <div className="space-y-4 text-sm">
                  <p className="text-slate-500 italic border-b border-blue-200 pb-2 mb-2">
                    <span className="font-bold not-italic text-blue-700">Situácia:</span> {selectedRule.details.script.situation}
                  </p>
                  
                  {selectedRule.details.script.isYouFirst ? (
                    <>
                      <div className="bg-blue-600 p-3 rounded-lg rounded-tr-none shadow-sm mr-4 text-white">
                        <span className="block text-xs font-bold text-blue-200 mb-1">VY (Aplikácia pravidla)</span>
                        <p>"{selectedRule.details.script.you}"</p>
                      </div>
                      
                      <div className="bg-white p-3 rounded-lg rounded-tl-none border border-blue-100 shadow-sm ml-4">
                        <span className="block text-xs font-bold text-slate-400 mb-1">DRUHÁ STRANA</span>
                        <p className="text-slate-700">"{selectedRule.details.script.them}"</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-white p-3 rounded-lg rounded-tl-none border border-blue-100 shadow-sm ml-4">
                        <span className="block text-xs font-bold text-slate-400 mb-1">DRUHÁ STRANA</span>
                        <p className="text-slate-700">"{selectedRule.details.script.them}"</p>
                      </div>

                      <div className="bg-blue-600 p-3 rounded-lg rounded-tr-none shadow-sm mr-4 text-white">
                        <span className="block text-xs font-bold text-blue-200 mb-1">VY (Aplikácia pravidla)</span>
                        <p>"{selectedRule.details.script.you}"</p>
                      </div>
                    </>
                  )}

                  <div className="bg-green-100 p-3 rounded-lg border border-green-200 mt-4">
                    <span className="font-bold text-green-800 text-xs uppercase block mb-1">Výsledok</span>
                    <p className="text-green-900 italic">{selectedRule.details.script.result}</p>
                  </div>
                </div>
              </div>
              )}

              <div className="bg-amber-50 rounded-2xl p-6 border border-amber-100">
                <h3 className="font-bold text-amber-900 mb-2 flex items-center gap-2">
                  <i className="fa-solid fa-lightbulb"></i> Tip z praxe
                </h3>
                <p className="text-amber-800 text-sm leading-relaxed">
                  {selectedRule.practical}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // RENDER LIST GRID (DEFAULT)
  return (
    <div className="container mx-auto px-6 pt-24 pb-12 animate-slide-up">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mt-2 mb-6">9 Pravidiel Komunikácie</h2>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Podľa Marka Goulstona (Just Listen). Kliknite na kartu pre detailný postup a príklady.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {rules.map((rule) => (
          <div 
            key={rule.id} 
            onClick={() => handleCardClick(rule.id)}
            className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-slate-100 group relative overflow-hidden flex flex-col h-full cursor-pointer"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-full -mr-16 -mt-16 group-hover:bg-blue-50 transition-colors"></div>
            
            <div className="relative z-10 flex flex-col flex-grow">
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl font-black text-slate-100 group-hover:text-blue-100 transition-colors">#{rule.id}</span>
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                  <i className={`fa-solid ${rule.icon} text-xl`}></i>
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-1 group-hover:text-blue-600 transition-colors">{rule.title}</h3>
              <p className="text-xs font-bold text-blue-500 uppercase tracking-wider mb-4">{rule.subtitle}</p>
              <p className="text-slate-600 text-sm leading-relaxed mb-4 flex-grow line-clamp-3">{rule.desc}</p>
              
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center text-blue-600 font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                Zobraziť detaily <i className="fa-solid fa-arrow-right ml-2"></i>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};