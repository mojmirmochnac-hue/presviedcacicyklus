import React from 'react';
import { SectionProps } from '../types';

export const SystemsView: React.FC<SectionProps> = ({ onBack }) => {
  return (
    <div className="container mx-auto px-6 pt-24 pb-12 animate-slide-up max-w-6xl">
      <button 
        onClick={onBack}
        className="mb-8 flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors group"
      >
        <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-50">
          <i className="fa-solid fa-arrow-left"></i>
        </div>
        Späť domov
      </button>

      <div className="text-center mb-16">
        <span className="text-red-500 font-bold tracking-wider text-sm uppercase">Daniel Kahneman</span>
        <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mt-2 mb-6">Systém 1 a Systém 2</h2>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Ľudský mozog nie je jeden procesor. Sú to dva odlišné systémy, ktoré spolu neustále bojujú o kontrolu nad vaším správaním.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-16 relative">
        {/* VS Badge */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white rounded-full shadow-xl flex items-center justify-center font-black text-slate-300 z-10 border-4 border-slate-50 hidden md:flex">
          VS
        </div>

        {/* System 1 Card */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border-t-8 border-red-500 relative overflow-hidden group hover:shadow-2xl transition-all">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <i className="fa-solid fa-bolt text-[10rem]"></i>
          </div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600 text-xl shadow-sm">
                  <i className="fa-solid fa-person-running"></i>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">Systém 1</h3>
              </div>
              <div className="text-right">
                <span className="block text-4xl font-black text-red-500">95%</span>
                <span className="text-xs text-red-400 uppercase font-bold tracking-widest">Času</span>
              </div>
            </div>
            <p className="text-red-600 font-medium mb-6 text-lg">Rýchle, intuitívne, emocionálne myslenie (Autopilot).</p>
            
            <ul className="space-y-4">
              {[
                { label: "Automatický pilot", desc: "Funguje bez úsilia, je stále zapnutý. Vytvára prvý dojem." },
                { label: "Asociačný stroj", desc: "Vytvára príbehy a kauzalitu, aj keď chýbajú fakty. Hľadá súvislosti." },
                { label: "WYSIATI", desc: "'What You See Is All There Is' - ignoruje to, čo nevidí (chýbajúce dáta)." },
                { label: "Emocionálny", desc: "Riadený amygdalou (strach, potešenie). Zdroj odporu." },
                { label: "Skáče k záverom", desc: "Uprednostňuje rýchlu istotu pred pochybnosťami." }
              ].map((item, idx) => (
                <li key={idx} className="flex items-start bg-red-50/50 p-3 rounded-lg hover:bg-red-50 transition-colors">
                  <i className="fa-solid fa-circle-check text-red-500 mt-1 mr-3 text-sm"></i>
                  <div>
                    <span className="block font-bold text-slate-800 text-sm">{item.label}</span>
                    <span className="text-slate-600 text-sm">{item.desc}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* System 2 Card */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border-t-8 border-blue-500 relative overflow-hidden group hover:shadow-2xl transition-all">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <i className="fa-solid fa-chess text-[10rem]"></i>
          </div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 text-xl shadow-sm">
                  <i className="fa-solid fa-brain"></i>
                </div>
                <h3 className="text-3xl font-bold text-slate-800">Systém 2</h3>
              </div>
              <div className="text-right">
                <span className="block text-4xl font-black text-blue-500">5%</span>
                <span className="text-xs text-blue-400 uppercase font-bold tracking-widest">Času</span>
              </div>
            </div>
            <p className="text-blue-600 font-medium mb-6 text-lg">Pomalé, racionálne, logické myslenie (Kontrolór).</p>
            
            <ul className="space-y-4">
              {[
                { label: "Vyžaduje úsilie", desc: "Spotrebúva glukózu a mentálnu energiu. Fyzicky bolí." },
                { label: "Lenivý", desc: "Mozog ho zapína len keď musí (zákon min. úsilia). Často len 'odkývne' S1." },
                { label: "Logický analytik", desc: "Počíta (17x24), overuje fakty, plánuje budúcnosť." },
                { label: "Zdroj súhlasu", desc: "Skutočné, trvalé 'ÁNO' musí prejsť tadeto." },
                { label: "Obmedzená kapacita", desc: "Pri preťažení (stres) sa vypína a preberá to Systém 1." }
              ].map((item, idx) => (
                <li key={idx} className="flex items-start bg-blue-50/50 p-3 rounded-lg hover:bg-blue-50 transition-colors">
                  <i className="fa-solid fa-circle-check text-blue-500 mt-1 mr-3 text-sm"></i>
                  <div>
                    <span className="block font-bold text-slate-800 text-sm">{item.label}</span>
                    <span className="text-slate-600 text-sm">{item.desc}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <div className="bg-slate-100 rounded-2xl p-6 border border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                <i className="fa-solid fa-link text-slate-500"></i> Interakcia
            </h4>
            <p className="text-sm text-slate-600">
                Systém 1 neustále generuje návrhy (pocity, intuície). Ak ich Systém 2 schváli (čo robí často bez kontroly), menia sa na presvedčenia a činy.
            </p>
        </div>
        <div className="bg-slate-100 rounded-2xl p-6 border border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                <i className="fa-solid fa-triangle-exclamation text-slate-500"></i> Riziko
            </h4>
            <p className="text-sm text-slate-600">
                Chyby nastávajú, keď Systém 1 "skočí k záveru" na základe emócie a lenivý Systém 2 to neskontroluje. (Príklad pálka a loptička).
            </p>
        </div>
        <div className="bg-slate-100 rounded-2xl p-6 border border-slate-200">
            <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                <i className="fa-solid fa-comments text-slate-500"></i> V komunikácii
            </h4>
            <p className="text-sm text-slate-600">
                Klient v odpore je v Systéme 1. Nemôžete naňho použiť logiku (S2), kým ho neupokojíte a nevytvoríte bezpečie pre zapnutie S2.
            </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-lg">
        <h3 className="text-2xl font-bold mb-8 text-slate-800 text-center">Kľúčové pravidlá pre prax (Podľa Kahnemana)</h3>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            { 
                title: "Vytvor podmienky pre Systém 2", 
                text: "Ak chceš racionálnu úvahu, klient potrebuje čas, pokoj a jasnú štruktúru. V strese je S2 'slepý'.", 
                icon: "fa-hourglass-half",
                color: "text-blue-600",
                bg: "bg-blue-50"
            },
            { 
                title: "Prvý názor je Systém 1", 
                text: "Počítaj s tým, že prvá reakcia klienta je automatická, rýchla a často obranná. Neber to ako definitívne stanovisko.", 
                icon: "fa-gauge-high",
                color: "text-red-600",
                bg: "bg-red-50"
            },
            { 
                title: "Nezvyšuj preťaženie", 
                text: "Keď je klient v kognitívnej námahe, jeho pozornosť sa zúži. Ďalšie argumenty vtedy doslova 'nevidí'.", 
                icon: "fa-weight-hanging",
                color: "text-orange-600",
                bg: "bg-orange-50"
            },
            { 
                title: "Pozor na ilúziu pravdy", 
                text: "Keď klient dáva rýchle a isté odpovede, je to často len 'kognitívna ľahkosť' (S1), nie skutočná znalosť.", 
                icon: "fa-fingerprint",
                color: "text-emerald-600",
                bg: "bg-emerald-50"
            }
          ].map((rule, idx) => (
            <div key={idx} className="flex gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${rule.bg} ${rule.color}`}>
                  <i className={`fa-solid ${rule.icon} text-xl`}></i>
              </div>
              <div>
                  <h4 className={`font-bold ${rule.color} text-lg mb-1`}>{rule.title}</h4>
                  <p className="text-slate-600 text-sm leading-relaxed">{rule.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};