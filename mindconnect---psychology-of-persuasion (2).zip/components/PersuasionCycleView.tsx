import React, { useState } from 'react';
import { SectionProps } from '../types';

export const PersuasionCycleView: React.FC<SectionProps> = ({ onBack, onNavigateToRule }) => {
  const [activeStep, setActiveStep] = useState<string>('resisting');

  // Hexagonal layout positions (Center 50,50)
  const positions = {
    center: { cx: 50, cy: 50, label: 'TY' },
    resisting: { cx: 32, cy: 20, label: "ODPOR" },
    listening: { cx: 68, cy: 20, label: "POČÚVANIE" },
    considering: { cx: 85, cy: 50, label: "ZVAŽOVANIE" },
    willing: { cx: 68, cy: 80, label: "OCHOTA" },
    doing: { cx: 32, cy: 80, label: "KONANIE" },
    glad: { cx: 15, cy: 50, label: "SPOKOJNOSŤ" }
  };

  const stepRules = {
    resisting: [
      { id: 1, name: "Najprv upokoj seba", context: "Kým si emočne aktivovaný, nevieš počúvať a presviedčanie je nemožné." },
      { id: 6, name: "Pomôž ľuďom “vydýchnuť”", context: "Po uvoľnení napätia je mozog schopný racionálneho uvažovania." },
      { id: 8, name: "Odkry krk", context: "Zraniteľnosť/priznanie chyby znižuje obranu (keď sa rozhovor zaseká alebo eskaluje)." },
      { id: 9, name: "Vyhýbaj sa toxickým ľuďom", context: "Ochrana energie a hraníc (ak je človek toxický, pravidlo hovorí chrániť seba)." }
    ],
    listening: [
      { id: 2, name: "Preprogramuj sa na počúvanie", context: "Prepnutie do režimu príjmu (vypnutie vnútorného monológu)." },
      { id: 3, name: "Daj pocit, že je “cítený”", context: "Musíte cítiť a pomenovať ich emóciu, nielen počúvať slová." },
      { id: 4, name: "Buď viac zvedavý než zaujímavý", context: "Úprimné otázky otvárajú človeka, snaha zaujať ho zatvára." },
      { id: 5, name: "Daj ľuďom pocit hodnoty", context: "Spolupráca rastie, keď cítia, že na nich záleží." },
      { id: 7, name: "Odlož kognitívnu disonanciu", context: "Ignoruj vnútorné rozpory a sústreď sa na druhého – aby si nevysielal “nesúlad”, ktorý spúšťa obranu." }
    ],
    considering: [
      { id: 4, name: "Buď viac zvedavý než zaujímavý", context: "Udržiava klienta v premýšľaní, lebo v cykle platí „pýtajte sa, netvrďte“." },
      { id: 5, name: "Daj ľuďom pocit hodnoty", context: "Udrží spoluprácu a otvorenosť počas zvažovania možností." },
      { id: 7, name: "Odlož kognitívnu disonanciu", context: "Dávate pozor, aby vaše slová/tón nepôsobili inak než chcete (disonancia zhoršuje spojenie)." }
    ],
    willing: [
      { id: 5, name: "Daj ľuďom pocit hodnoty", context: "Posilňuje ochotu spolupracovať a ísť do akcie." },
      { id: 4, name: "Buď viac zvedavý než zaujímavý", context: "Nechajte klienta, nech si riešenie “vysvetlí sám”." },
      { id: 7, name: "Odlož kognitívnu disonanciu", context: "Aby sa nevytvoril pocit tlaku alebo nedôvery tesne pred rozhodnutím." }
    ],
    doing: [
      { id: 7, name: "Odlož kognitívnu disonanciu", context: "Aby “konanie” a inštrukcie nepôsobili ako manipulácia alebo tlačenie." },
      { id: 5, name: "Daj ľuďom pocit hodnoty", context: "Zachovať kooperatívny tón a rešpekt aj počas realizácie." }
    ],
    glad: [
      { id: 3, name: "Daj pocit, že je “cítený”", context: "Klient odchádza s vnútorným pokojom a bez potreby sa obhajovať." },
      { id: 5, name: "Daj ľuďom pocit hodnoty", context: "Potvrdenie správnosti rozhodnutia upevňuje lojalitu." }
    ]
  };

  const steps = {
    resisting: {
      id: 'resisting',
      title: "Odpor (Resisting)",
      action: "Neobhajuj sa. Počúvaj.",
      desc: "Klient je v 'Oh F#@&' móde (Systém 1). Vníma vás ako hrozbu alebo narušiteľa. Akákoľvek logika tu zlyháva a len zvyšuje odpor. Cieľom nie je presvedčiť, ale nechať ho 'vydýchnuť' a znížiť napätie.",
      color: "bg-red-500",
      hoverColor: "hover:text-red-600",
      ringColor: "ring-red-300",
      icon: "fa-hand",
      pos: "top-[20%] left-[32%] -translate-x-1/2 -translate-y-1/2"
    },
    listening: {
      id: 'listening',
      title: "Aktívne počúvanie (Listening)",
      action: "Empatia a Ticho",
      desc: "Keď napätie klesne, začnite počúvať. Použite techniku 'Make them feel felt' - pomenujte ich pocity ('Znie to, že ste frustrovaný...'). Tým vytvoríte psychologické bezpečie.",
      color: "bg-orange-500",
      hoverColor: "hover:text-orange-600",
      ringColor: "ring-orange-300",
      icon: "fa-ear-listen",
      pos: "top-[20%] left-[68%] -translate-x-1/2 -translate-y-1/2" 
    },
    considering: {
      id: 'considering',
      title: "Zvažovanie (Considering)",
      action: "Predostri víziu",
      desc: "Prechod do Systému 2. Klient prestal bojovať a začína premýšľať. Pýtajte sa: 'Čo keby sme...?' Nechajte ho samého prísť na riešenie.",
      color: "bg-yellow-500",
      hoverColor: "hover:text-yellow-600",
      ringColor: "ring-yellow-300",
      icon: "fa-scale-balanced",
      pos: "top-[50%] left-[85%] -translate-x-1/2 -translate-y-1/2" 
    },
    willing: {
      id: 'willing',
      title: "Ochota konať (Willing)",
      action: "Dohodni konkrétne kroky",
      desc: "Klient vidí riešenie a je pripravený. Teraz (a až teraz!) môžete predostrieť fakty a dáta na potvrdenie ich rozhodnutia.",
      color: "bg-blue-500",
      hoverColor: "hover:text-blue-600",
      ringColor: "ring-blue-300",
      icon: "fa-thumbs-up",
      pos: "top-[80%] left-[68%] -translate-x-1/2 -translate-y-1/2" 
    },
    doing: {
      id: 'doing',
      title: "Konanie (Doing)",
      action: "Uzavretie dohody",
      desc: "Realizácia a záväzok. Dôležité je udržať momentum a nevytvoriť nový odpor tlakom.",
      color: "bg-green-500",
      hoverColor: "hover:text-green-600",
      ringColor: "ring-green-300",
      icon: "fa-signature",
      pos: "top-[80%] left-[32%] -translate-x-1/2 -translate-y-1/2" 
    },
    glad: {
      id: 'glad',
      title: "Spokojnosť (Glad)",
      action: "Upevnenie vzťahu",
      desc: "Prevencia výčitiek (Buyer's Remorse). Pripomeňte im ICH dôvody pre rozhodnutie. Ak sú spokojní, budú 'pokračovať v tom, čo začali'.",
      color: "bg-emerald-600",
      hoverColor: "hover:text-emerald-600",
      ringColor: "ring-emerald-300",
      icon: "fa-face-smile",
      pos: "top-[50%] left-[15%] -translate-x-1/2 -translate-y-1/2" 
    }
  };

  const currentStep = steps[activeStep as keyof typeof steps];
  const currentStepRules = stepRules[activeStep as keyof typeof stepRules];

  return (
    <div className="container mx-auto px-4 pt-24 pb-12 animate-fade-in max-w-6xl">
      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900 mb-4">Presviedčací Cyklus</h2>
        <p className="text-lg text-slate-600 max-w-3xl mx-auto">
          Cyklus začína odporom. Vašou úlohou je previesť partnera cez jednotlivé fázy až k spokojnosti. Kliknite na fázu pre zobrazenie odporúčaných pravidiel.
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-12 items-center lg:items-start">
        
        {/* Interactive Circular Diagram */}
        <div className="relative w-[350px] h-[350px] md:w-[550px] md:h-[550px] flex-shrink-0 select-none mx-auto lg:mx-0">
          
          {/* Connecting Lines (SVG Overlay) */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-visible" viewBox="0 0 100 100">
            <defs>
              <marker id="arrowhead" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                <path d="M0,0 L0,6 L6,3 z" fill="#94a3b8" />
              </marker>
              <marker id="arrowhead-start" markerWidth="6" markerHeight="6" refX="1" refY="3" orient="auto">
                <path d="M6,0 L6,6 L0,3 z" fill="#94a3b8" />
              </marker>
              <marker id="arrowhead-red" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                <path d="M0,0 L0,6 L6,3 z" fill="#ef4444" />
              </marker>
            </defs>

            {/* Inner Double Arrows (TY <-> Nodes) */}
            <line x1="45" y1="42" x2="36" y2="27" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />
            <line x1="55" y1="42" x2="64" y2="27" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />
            <line x1="58" y1="50" x2="77" y2="50" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />
            <line x1="54" y1="58" x2="64" y2="73" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />
            <line x1="46" y1="58" x2="36" y2="73" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />
            <line x1="42" y1="50" x2="23" y2="50" stroke="#cbd5e1" strokeWidth="0.8" markerEnd="url(#arrowhead)" markerStart="url(#arrowhead-start)" />

            {/* Outer Flow Arrows (Clockwise) */}
            <path d="M 38 18 L 60 18" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />
            <path d="M 74 25 L 82 42" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />
            <path d="M 82 58 L 74 75" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />
            <path d="M 60 82 L 40 82" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />
            <path d="M 26 75 L 18 58" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />

            {/* Special Arrow: Glad -> Continue (Outward) */}
            <path d="M 15 42 L 15 25" fill="none" stroke="#cbd5e1" strokeWidth="1" markerEnd="url(#arrowhead)" />
            
            {/* Special Arrow: Resistance to Doing (Doing -> Resisting) */}
            <path d="M 28 80 Q 5 50 28 25" fill="none" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 3" markerEnd="url(#arrowhead-red)" opacity="0.6" />

          </svg>

          {/* Labels on Diagram */}
          <div className="absolute top-[18%] left-[5%] w-24 text-center text-[10px] md:text-xs text-slate-400 font-medium -rotate-12 pointer-events-none">
            pokračujú v tom, čo začali
          </div>
          <div className="absolute top-[45%] left-[-2%] w-24 text-center text-[10px] md:text-xs text-red-400 font-bold -rotate-90 pointer-events-none opacity-70">
            odpor voči konaniu
          </div>

          {/* Center Node: TY */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
            <div className="w-20 h-20 md:w-28 md:h-28 bg-white rounded-full border-4 border-slate-300 shadow-xl flex flex-col items-center justify-center relative z-20 group hover:scale-105 transition-transform duration-300">
              <i className="fa-solid fa-user text-2xl md:text-4xl text-slate-400 mb-1"></i>
              <span className="font-black text-xl md:text-2xl text-slate-700">TY</span>
            </div>
            {/* Pulse effect behind center */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-slate-100 rounded-full -z-10 animate-ping opacity-20"></div>
          </div>

          {/* Orbital Nodes */}
          {Object.entries(steps).map(([key, step]) => {
            const posData = positions[key as keyof typeof positions];
            return (
              <div 
                key={key}
                onClick={() => setActiveStep(key)}
                className={`absolute ${step.pos} cursor-pointer group z-30 transition-all duration-500`}
              >
                <div className={`
                  w-20 h-20 md:w-28 md:h-28 rounded-full border-[3px] shadow-lg flex flex-col items-center justify-center text-center p-1 transition-all duration-300 bg-white
                  ${activeStep === key 
                    ? `scale-110 border-white ring-4 ${step.ringColor} ${step.color} text-white` 
                    : `border-slate-300 hover:border-slate-400 text-slate-500 ${step.hoverColor}`}
                `}>
                  <i className={`fa-solid ${step.icon} text-lg mb-1 block`}></i>
                  <span className="text-[9px] md:text-[10px] font-bold leading-tight uppercase px-1">{posData.label}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Details Panel */}
        <div className="flex-1 w-full">
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-slate-100 relative overflow-hidden h-full min-h-[400px]">
            {/* Background Icon */}
            <div className="absolute -right-10 -bottom-10 opacity-5 text-[15rem] transition-all duration-500">
              <i className={`fa-solid ${currentStep.icon}`}></i>
            </div>

            <div className="relative z-10 animate-fade-in key={activeStep}">
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-14 h-14 rounded-2xl ${currentStep.color} flex items-center justify-center text-white text-2xl shadow-lg`}>
                  <i className={`fa-solid ${currentStep.icon}`}></i>
                </div>
                <div>
                  <h3 className="text-2xl md:text-3xl font-bold text-slate-800">{currentStep.title}</h3>
                  <span className="text-sm font-semibold tracking-wider text-slate-400 uppercase">Fáza cyklu</span>
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-6 border-l-4 border-slate-300 mb-6">
                <h4 className="font-bold text-slate-700 mb-2 text-sm uppercase">Cieľ:</h4>
                <p className="text-lg font-medium text-slate-800">{currentStep.action}</p>
                <p className="text-sm text-slate-600 mt-2 italic">{currentStep.desc}</p>
              </div>

              {/* RULES LINKS SECTION */}
              <div className="mb-8">
                <h4 className="font-bold text-slate-700 mb-4 text-sm uppercase flex items-center gap-2">
                  <i className="fa-solid fa-link text-blue-500"></i> Tu sa najviac používajú pravidlá:
                </h4>
                <div className="flex flex-col gap-3">
                  {currentStepRules.map((rule) => (
                    <div 
                      key={rule.id}
                      onClick={() => onNavigateToRule && onNavigateToRule(rule.id)}
                      className="group cursor-pointer bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <span className="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-full group-hover:bg-blue-700 transition-colors">
                          Pravidlo #{rule.id}
                        </span>
                        <h5 className="font-bold text-slate-800 group-hover:text-blue-700 transition-colors flex-grow">
                          {rule.name} <i className="fa-solid fa-arrow-up-right-from-square ml-2 text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>
                        </h5>
                      </div>
                      <p className="text-sm text-slate-600 group-hover:text-slate-700 leading-snug">
                        {rule.context}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-6">
                <div className="flex gap-2 flex-wrap">
                  {(activeStep === 'resisting' || activeStep === 'listening') && (
                    <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold">Systém 1 (Emócie)</span>
                  )}
                  {(activeStep === 'considering' || activeStep === 'willing') && (
                    <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">Systém 2 (Rozum)</span>
                  )}
                  <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-bold">
                    <i className="fa-regular fa-clock mr-1"></i> Trpezlivosť
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Hint */}
      <p className="text-center text-slate-400 text-sm mt-8 lg:hidden">
        <i className="fa-solid fa-hand-pointer mr-2"></i> Kliknite na bublinu v kruhu pre viac informácií
      </p>
    </div>
  );
};