import React, { useEffect } from 'react';
import { SectionProps } from '../types';

export const AuthorsView: React.FC<SectionProps> = ({ onBack }) => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="container mx-auto px-6 pt-24 pb-12 animate-fade-in max-w-5xl">
      <button 
        onClick={onBack}
        className="mb-8 flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors group"
      >
        <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-50">
          <i className="fa-solid fa-arrow-left"></i>
        </div>
        Späť domov
      </button>

      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Zdroje a Inšpirácia</h2>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Celá metodika tejto aplikácie vychádza z vedeckých poznatkov a praxe týchto dvoch expertov na ľudskú myseľ.
        </p>
      </div>

      <div className="space-y-12">
        {/* Daniel Kahneman */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 flex flex-col md:flex-row">
          <div className="md:w-1/3 bg-slate-100 p-8 flex flex-col items-center justify-center border-r border-slate-200">
            <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-md mb-6 text-slate-400 text-5xl">
              <i className="fa-solid fa-brain"></i>
            </div>
            <h3 className="text-2xl font-bold text-slate-900 text-center">Daniel Kahneman</h3>
            <p className="text-slate-500 text-sm mt-2 text-center">Nobelova cena za ekonómiu (2002)</p>
          </div>
          <div className="p-8 md:w-2/3">
            <h4 className="text-xl font-bold text-blue-600 mb-2 flex items-center gap-2">
              <i className="fa-solid fa-book"></i> Kniha: Thinking, Fast and Slow
            </h4>
            <h5 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Myslenie rýchle a pomalé</h5>
            
            <p className="text-slate-600 leading-relaxed mb-6">
              Kahneman v tomto prelomovom diele popísal, ako náš mozog používa dva systémy myslenia. Väčšina našich chýb v komunikácii vzniká, keď sa snažíme logicky argumentovať (Systém 2) niekomu, kto reaguje emocionálne a intuitívne (Systém 1).
            </p>

            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
              <strong className="block text-slate-800 mb-3 text-sm">Kľúčové koncepty v aplikácii:</strong>
              <ul className="grid gap-2 text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>Systém 1 vs Systém 2:</strong> Prečo logika nefunguje na emócie.</span>
                </li>
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>Cognitive Ease (Kognitívna ľahkosť):</strong> Ak chcete niekoho presvedčiť, musíte mu uľahčiť premýšľanie.</span>
                </li>
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>WYSIATI:</strong> "What You See Is All There Is" - ľudia posudzujú situáciu len podľa toho, čo vidia práve teraz.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Mark Goulston */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 flex flex-col md:flex-row">
          <div className="md:w-1/3 bg-slate-100 p-8 flex flex-col items-center justify-center border-r border-slate-200">
            <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-md mb-6 text-slate-400 text-5xl">
              <i className="fa-solid fa-ear-listen"></i>
            </div>
            <h3 className="text-2xl font-bold text-slate-900 text-center">Mark Goulston</h3>
            <p className="text-slate-500 text-sm mt-2 text-center">Psychiater & FBI Vyjednávač</p>
          </div>
          <div className="p-8 md:w-2/3">
            <h4 className="text-xl font-bold text-indigo-600 mb-2 flex items-center gap-2">
              <i className="fa-solid fa-book"></i> Kniha: Just Listen
            </h4>
            <h5 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Počúvajte! (Tajomstvo úspešnej komunikácie)</h5>
            
            <p className="text-slate-600 leading-relaxed mb-6">
              Mark Goulston učil vyjednávačov FBI, ako hovoriť s únoscami a samovrahmi. Zistil, že rovnaké princípy "odistenia" mozgu fungujú aj na nahnevaných klientov, manželov či tínedžerov. Jeho metóda je o premostení priepasti medzi ľuďmi.
            </p>

            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
              <strong className="block text-slate-800 mb-3 text-sm">Kľúčové koncepty v aplikácii:</strong>
              <ul className="grid gap-2 text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>Presviedčací cyklus:</strong> Cesta od odporu k počúvaniu a ochote.</span>
                </li>
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>Amygdala Hijack:</strong> Ako upokojiť človeka v "móde prežitia".</span>
                </li>
                <li className="flex items-start gap-2">
                  <i className="fa-solid fa-check text-green-500 mt-1"></i>
                  <span><strong>Make them feel felt:</strong> Technika empatického zrkadlenia.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};