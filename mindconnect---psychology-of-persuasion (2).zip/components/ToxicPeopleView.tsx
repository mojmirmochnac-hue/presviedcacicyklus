import React, { useState, useEffect } from 'react';
import { SectionProps } from '../types';

type ViewState = 'MENU' | 'NEEDY' | 'BULLY' | 'TAKER' | 'NARCISSIST' | 'PSYCHOPATH';
type QuizState = 'INTRO' | 'QUESTIONS' | 'RESULT';

interface QuizQuestion {
  id: number;
  text: string;
}

// --- QUIZ DATA ---

const needyQuestions: QuizQuestion[] = [
  { id: 1, text: "Narieka táto osoba často?" },
  { id: 2, text: "Neustále sa sťažuje?" },
  { id: 3, text: "Vystupuje ako obeť okolností?" },
  { id: 4, text: "Zdá sa, že jej postoj hovorí: „Ľutuj ma“?" },
  { id: 5, text: "Vyžaduje si ľútosť od ostatných?" },
  { id: 6, text: "Plače alebo sa tvári hlboko ublížene, keď niečo nejde podľa nej?" },
  { id: 7, text: "Snaží sa vo vás vyvolať pocit viny?" },
  { id: 8, text: "Pripadá vám ako „bezodná jama“, ktorej potreby sa nedajú nikdy naplniť?" },
  { id: 9, text: "Máte chuť sa tejto osobe vyhnúť?" },
  { id: 10, text: "Stiahne sa vám žalúdok, keď od nej vidíte hovor alebo e-mail?" },
  { id: 11, text: "Máte chuť na ňu zakričať: „Vzchop sa!“?" },
  { id: 12, text: "Cítite sa vinní, pretože prestávate túto osobu podporovať (len aby ste mali pokoj)?" }
];

const narcissistQuestions: QuizQuestion[] = [
  { id: 1, text: "Ako často musí mať pravdu za každú cenu?" },
  { id: 2, text: "Ako často je netrpezlivá bez dobrého dôvodu?" },
  { id: 3, text: "Ako často vás preruší, ale urazí sa, ak prerušíte vy ju?" },
  { id: 4, text: "Ako často očakáva, že všetko necháte a budete ju počúvať (ale neoplatí to)?" },
  { id: 5, text: "Ako často hovorí viac, než počúva?" },
  { id: 6, text: "Ako často hovorí „Áno, ale...“, „To nie je pravda“, „Tvoj problém je...“?" },
  { id: 7, text: "Ako často odmieta urobiť niečo čo je pre Vás dôležité, ale pre ňu nepohodlné?" },
  { id: 8, text: "Ako často očakáva, že vy pre ňu urobíte niečo nepohodlné?" },
  { id: 9, text: "Ako často očakáva, že budete tolerovať správanie, ktoré by ona netolerovala vám?" },
  { id: 10, text: "Ako často zabudne povedať „Ďakujem“ alebo „Prepáč“, keď je to na mieste?" }
];

// --- COMPONENTS ---

const QuizComponent = ({ 
  questions, 
  onFinish, 
  title 
}: { 
  questions: QuizQuestion[], 
  onFinish: (score: number) => void,
  title: string
}) => {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  
  const handleAnswer = (questionId: number, value: number) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const calculateScore = () => {
    return (Object.values(answers) as number[]).reduce((a, b) => a + b, 0);
  };

  const allAnswered = questions.every(q => answers[q.id] !== undefined);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 md:p-8 animate-fade-in">
      <h3 className="text-xl font-bold text-slate-800 mb-6 border-b pb-4">📝 {title} - Test</h3>
      <p className="text-sm text-slate-500 mb-6">Ohodnoťte každú otázku na škále: <br/><strong>1 = Vôbec / Zriedka</strong> | <strong>2 = Niekedy</strong> | <strong>3 = Často / Takmer vždy</strong></p>
      
      <div className="space-y-6">
        {questions.map((q) => (
          <div key={q.id} className="bg-slate-50 p-4 rounded-lg">
            <p className="font-medium text-slate-800 mb-3">{q.id}. {q.text}</p>
            <div className="flex gap-2">
              {[1, 2, 3].map((val) => (
                <button
                  key={val}
                  onClick={() => handleAnswer(q.id, val)}
                  className={`flex-1 py-2 rounded-md text-sm font-bold transition-all ${
                    answers[q.id] === val 
                      ? 'bg-blue-600 text-white shadow-md' 
                      : 'bg-white border border-slate-300 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-6 border-t border-slate-200">
        <button
          onClick={() => allAnswered && onFinish(calculateScore())}
          disabled={!allAnswered}
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
            allAnswered 
              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1' 
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          {allAnswered ? 'Vyhodnotiť test' : `Zodpovedajte všetky otázky (${Object.keys(answers).length}/${questions.length})`}
        </button>
      </div>
    </div>
  );
};

export const ToxicPeopleView: React.FC<SectionProps> = ({ onBack }) => {
  const [view, setView] = useState<ViewState>('MENU');
  const [quizState, setQuizState] = useState<QuizState>('INTRO');
  const [score, setScore] = useState<number>(0);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view, quizState]);

  const handleStartQuiz = () => {
    setQuizState('QUESTIONS');
    setScore(0);
  };

  const handleFinishQuiz = (finalScore: number) => {
    setScore(finalScore);
    setQuizState('RESULT');
  };

  const resetToMenu = () => {
    setView('MENU');
    setQuizState('INTRO');
    setScore(0);
  };

  // --- RENDER CONTENT BASED ON VIEW ---

  const renderNeedy = () => (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="bg-blue-50 p-8 rounded-3xl border border-blue-100 text-center">
        <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl shadow-sm">
          <i className="fa-solid fa-bucket"></i>
        </div>
        <h2 className="text-3xl font-extrabold text-blue-900 mb-2">Večne Potrební (The Needy)</h2>
        <p className="text-blue-700 max-w-2xl mx-auto">
          "Potrebujem, aby si vyriešil všetky moje problémy. Bez teba nemôžem existovať."
        </p>
      </div>

      {quizState === 'INTRO' && (
        <>
          <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
            <p>
              Existujú ľudia, ktorí potrebujú pomoc, ocenia ju a pohnú sa ďalej. A potom sú tu <strong>Večne Potrební</strong>. 
              Títo ľudia vás citovo alebo finančne vycicajú. Ich potreby sú ako bezodná jama. Ak sa im snažíte pomôcť, 
              iba sa hlbšie ponárate do ich močiara. Používajú citové vydieranie a ak sa ich pokúsite striasť, 
              chytia sa vás ešte pevnejšie.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <i className="fa-solid fa-shield-halved text-blue-500"></i> Stratégia: Bolestivá konfrontácia
            </h3>
            <p className="text-sm text-slate-600 mb-4">
              Ak vzťah chcete zachrániť, musíte nastaviť zrkadlo. Povedzte toto (a tvárte sa, že vás to bolí hovoriť):
            </p>
            <div className="bg-slate-50 p-4 rounded-xl border-l-4 border-blue-500 italic text-slate-700 text-sm">
              "Začínam sa ti vyhýbať, pretože takmer zakaždým, keď sa ťa na niečo spýtam, nájdeš výhovorku alebo obviníš niekoho iného. 
              A keď ťa konfrontujem, buď sa urazíš, rozplačeš alebo nahneváš. 
              Je pre mňa príliš vyčerpávajúce byť v tvojej blízkosti. Mám právo sa ti vyhýbať – a to aj budem robiť, ak nezačneš brať zodpovednosť za svoj život."
            </div>
          </div>

          <div className="text-center py-8">
            <button 
              onClick={handleStartQuiz}
              className="bg-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:bg-blue-700 hover:scale-105 transition-all flex items-center gap-3 mx-auto"
            >
              <i className="fa-solid fa-clipboard-check"></i>
              Urobiť test: Je táto osoba toxická?
            </button>
          </div>
        </>
      )}

      {quizState === 'QUESTIONS' && (
        <QuizComponent 
          title="Test: Večne Potrební" 
          questions={needyQuestions} 
          onFinish={handleFinishQuiz} 
        />
      )}

      {quizState === 'RESULT' && (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden animate-slide-up">
          <div className={`p-8 text-center text-white ${score <= 12 ? 'bg-green-500' : score <= 24 ? 'bg-orange-400' : 'bg-red-600'}`}>
            <h3 className="text-4xl font-black mb-2">{score} bodov</h3>
            <p className="text-lg font-medium opacity-90">Výsledok testu</p>
          </div>
          <div className="p-8 space-y-6">
            <div className="space-y-4">
              <div className={`p-4 rounded-xl border-l-4 ${score <= 12 ? 'bg-green-50 border-green-500' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">12 bodov: Nízka potreba pomoci</strong>
                <p className="text-sm">Osoba, ktorú sa oplatí mať v živote.</p>
              </div>
              <div className={`p-4 rounded-xl border-l-4 ${score > 12 && score <= 24 ? 'bg-orange-50 border-orange-500' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">13-24 bodov: Stredná potreba pomoci</strong>
                <p className="text-sm">Stojí tento vzťah skutočne za váš čas?</p>
              </div>
              <div className={`p-4 rounded-xl border-l-4 ${score > 24 ? 'bg-red-50 border-red-600' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">25-36 bodov: Vysoká potreba pomoci (TOXICKÉ)</strong>
                <p className="text-sm font-bold text-red-700">Odíďte (ak môžete) skôr, než z vás táto osoba vysaje život.</p>
              </div>
            </div>
            <button onClick={resetToMenu} className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors">
              Späť na prehľad typov
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderNarcissist = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-purple-50 p-8 rounded-3xl border border-purple-100 text-center">
        <div className="w-20 h-20 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl shadow-sm">
          <i className="fa-solid fa-crown"></i>
        </div>
        <h2 className="text-3xl font-extrabold text-purple-900 mb-2">Narcisti (Narcissists)</h2>
        <p className="text-purple-700 max-w-2xl mx-auto">
          "Zrkadielko, zrkadielko... dosť bolo o tebe, poďme hovoriť o mne."
        </p>
      </div>

      {quizState === 'INTRO' && (
        <>
          <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
            <p>
              Nie sú tu na to, aby vám ublížili, ale je im jedno, či vám ublížia. Nezaujímajú sa o vás – slúžite len ako publikum pre ich úžasnosť.
              Ich motto je: <em>"Tak... a dosť bolo o tebe."</em> (A to aj vtedy, ak ste ešte neotvorili ústa!).
              Často sú úspešní (herci, právnici, politici), takže vzťah s nimi môže byť vzrušujúci, ale nikdy nebude rovnocenný.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <i className="fa-solid fa-lightbulb text-purple-500"></i> Stratégia: Manažment očakávaní
            </h3>
            <p className="text-sm text-slate-600 mb-2">
              Ak musíte s narcisom pracovať, <strong>nikdy nečakajte, že urobí niečo, čo nie je v jeho najlepšom záujme.</strong>
            </p>
            <p className="text-sm text-slate-600">
              Nečakajte empatiu. Nečakajte vďaku. Ak to pochopíte, nebudete sklamaní. Ak chcete, aby niečo urobil, musíte to prezentovať tak, že to prospeje JEMU a jeho egu.
            </p>
          </div>

          <div className="text-center py-8">
            <button 
              onClick={handleStartQuiz}
              className="bg-purple-600 text-white px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:bg-purple-700 hover:scale-105 transition-all flex items-center gap-3 mx-auto"
            >
              <i className="fa-solid fa-clipboard-check"></i>
              Urobiť test: Mám dočinenia s narcisom?
            </button>
          </div>
        </>
      )}

      {quizState === 'QUESTIONS' && (
        <QuizComponent 
          title="Test: Narcistické črty" 
          questions={narcissistQuestions} 
          onFinish={handleFinishQuiz} 
        />
      )}

      {quizState === 'RESULT' && (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden animate-slide-up">
          <div className={`p-8 text-center text-white ${score <= 16 ? 'bg-green-500' : score <= 23 ? 'bg-orange-400' : 'bg-purple-600'}`}>
            <h3 className="text-4xl font-black mb-2">{score} bodov</h3>
            <p className="text-lg font-medium opacity-90">Výsledok testu</p>
          </div>
          <div className="p-8 space-y-6">
            <div className="space-y-4">
              <div className={`p-4 rounded-xl border-l-4 ${score <= 16 ? 'bg-green-50 border-green-500' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">10-16 bodov: Kooperatívna osoba</strong>
                <p className="text-sm">V rámci normy, dá sa s ňou spolupracovať.</p>
              </div>
              <div className={`p-4 rounded-xl border-l-4 ${score > 16 && score <= 23 ? 'bg-orange-50 border-orange-500' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">17-23 bodov: Hádavá osoba</strong>
                <p className="text-sm">Náročná povaha, pravdepodobne egocentrická.</p>
              </div>
              <div className={`p-4 rounded-xl border-l-4 ${score > 23 ? 'bg-purple-50 border-purple-600' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                <strong className="block text-lg">24-30 bodov: Narcista</strong>
                <p className="text-sm font-bold text-purple-700">Toxická miera narcizmu. Nečakajte rovnocenný vzťah.</p>
              </div>
            </div>
            <button onClick={resetToMenu} className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors">
              Späť na prehľad typov
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderBully = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-slate-800 p-8 rounded-3xl border border-slate-700 text-center text-white">
        <div className="w-20 h-20 bg-slate-700 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl shadow-sm">
          <i className="fa-solid fa-hand-fist"></i>
        </div>
        <h2 className="text-3xl font-extrabold text-white mb-2">Tyrani (Bullies)</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          "Útočia, pretože si myslia, že ste ľahká korisť."
        </p>
      </div>

      <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
        <p>
          Bol som na súdnom procese s O. J. Simpsonom a sledoval som pojednávanie na žiadosť obžaloby. Právnici chceli, aby som im dával návrhy (ktorými sa často neriadili... ale to je iný príbeh).
        </p>
        <p>
          Zrazu sa v jednom bode procesu neslávne známy obhajca F. Lee Bailey opýtal Marka Fuhrmana – vyšetrujúceho dôstojníka, ktorý bol v tom čase pod paľbou obhajoby – či ma pozná. Ukázal na mňa v súdnej sieni a Bailey falošne naznačil, že som Fuhrmana inštruoval v jeho výpovedi. Okamžite som sa ocitol v centre pozornosti a v celoštátnej televízii.
        </p>
        <p>
          Neskôr, na stretnutí s právnikmi obžaloby a mnou, sa Bailey pokúsil vzniesť rovnaké obvinenie priamo mne do tváre. Ale ja som vedel niečo o tom, ako zaobchádzať s ľuďmi ako Bailey, takže som neurobil to, čo očakával.
        </p>
        <p>
          Niekoľko minút Bailey hovoril veci ako: „Dr. Goulston, nevieme presne, prečo ste tu, ale vieme, že ste tu boli počas väčšiny procesu.“ Kým hovoril, pozeral som sa mu priamo do očí. Namiesto toho, aby som niečo povedal alebo urobil, som len občas žmurkol.
        </p>
        <p>
          Nakoniec sa na mňa pozrel iný právnik a povedal: „Mark, ty na to nič nepovieš?“ V tom momente som povedal: „Nepoložil mi otázku.“ Vrátil som sa k pozeraniu Baileymu do očí a on mierne cukol.
        </p>
        <p>
          Ďalej sa Bailey opýtal, či som Fuhrmanovi vymyl mozog alebo ho nadrogoval, alebo nejako inak pripravil na jeho výpoveď. Pripomenulo mi to chvíľu, keď zahnal Fuhrmana do kúta počas krížového výsluchu pri nezabudnuteľnom incidente so slovom „Neger“. Jasne dúfal, že spanikárim a poviem niečo hlúpe, čo by mohol prekrútiť alebo skresliť.
        </p>
        <p>
          Aj keď ste nevinný, je dosť zastrašujúce byť „grilovaný“ F. Lee Baileym. Mal som však výhodu, že som videl cez jeho hru: jeho cieľom bolo odzbrojiť ma, frustrovať a potom rozzúriť, aby som stratil chladnú hlavu.
        </p>
        <p>
          Takže keď sa opýtal, či som Fuhrmana nadrogoval alebo mu vymyl mozog – čo bola nehorázna otázka – čakal som celých sedem sekúnd a potom som si odkašľal. V tom momente všetci v miestnosti so zatajeným dychom čakali, čo poviem. Napočítal som ďalších sedem sekúnd a povedal som Baileymu: „Prepáčte, pán Bailey, moja myseľ sa za posledných pár minút niekam zatúlala. Môžete, prosím, zopakovať, čo ste povedali?“
        </p>
        <p>
          Bol úplne ohromený. Ako som sa mohol opovážiť považovať najzastrašujúcejšieho právnika na svete za takého nudného, že som sa nechal rozptýliť?
          A potom ustúpil – čo dokazuje, že ak nehráte hru tyrana, zvyčajne nemá záložný plán.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="font-bold text-slate-800 mb-4">Stratégia 1: Nuda (Bezpečná)</h3>
          <ul className="space-y-3 text-sm text-slate-600">
            <li className="flex items-start gap-2"><i className="fa-solid fa-check text-green-500 mt-1"></i> Udržujte očný kontakt.</li>
            <li className="flex items-start gap-2"><i className="fa-solid fa-check text-green-500 mt-1"></i> Tvárte sa zdvorilo, ale mierne znudene.</li>
            <li className="flex items-start gap-2"><i className="fa-solid fa-check text-green-500 mt-1"></i> Nekrižujte ruky (obrana), nechajte ich voľne visieť.</li>
            <li className="flex items-start gap-2"><i className="fa-solid fa-check text-green-500 mt-1"></i> Keď zistia, že ich hra na vás nefunguje, pôjdu hľadať ľahší cieľ.</li>
          </ul>
        </div>
        <div className="bg-red-50 p-6 rounded-2xl shadow-sm border border-red-100">
          <h3 className="font-bold text-red-900 mb-4">Stratégia 2: Úder späť (Riskantná)</h3>
          <p className="text-sm text-red-800 mb-3">
            Len ak máte únikovú stratégiu. Tyrani nie sú zvyknutí, že sa im niekto postaví.
          </p>
          <div className="bg-white p-3 rounded-lg text-xs italic text-slate-600 border border-red-200">
            "Nechcel by som pre teba pracovať. Bál by som sa ti povedať o chybe, pretože tvoje pohŕdanie hraničí so zneužívaním. Život je príliš krátky na to, aby som trpel tyrana ako si ty."
          </div>
        </div>
      </div>
    </div>
  );

  const renderTaker = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-green-50 p-8 rounded-3xl border border-green-100 text-center">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl shadow-sm">
          <i className="fa-solid fa-hand-holding-dollar"></i>
        </div>
        <h2 className="text-3xl font-extrabold text-green-900 mb-2">Berači (Takers)</h2>
        <p className="text-green-700 max-w-2xl mx-auto">
          "Môžeš pre mňa urobiť láskavosť? (Zase... a nič za to nečakaj.)"
        </p>
      </div>

      <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
        <p>
          Títo ľudia vám nezničia život, ale zničia vám deň. Neustále žiadajú o láskavosti ("Zoberieš za mňa službu?", "Pozrieš sa mi na tento report?"), ale nikdy nemajú čas pomôcť vám. Robia vás neproduktívnymi, pretože robíte ich prácu.
        </p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-lg border-l-8 border-green-500">
        <h3 className="font-bold text-xl text-slate-800 mb-6">Stratégia: Quid Pro Quo (Niečo za niečo)</h3>
        <p className="text-slate-600 mb-6">
          Najjednoduchší trik v knihe. Keď vás požiadajú o láskavosť, okamžite požiadajte o niečo vy.
        </p>
        
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="font-bold text-green-600 w-20 text-right uppercase text-xs pt-1">Berač</div>
            <div className="bg-slate-100 p-3 rounded-lg rounded-tl-none text-slate-700 text-sm flex-1">
              "Hej, mohol by si urobiť tie grafy do mojej prezentácie? Nestíham to."
            </div>
          </div>
          <div className="flex gap-4 flex-row-reverse">
            <div className="font-bold text-blue-600 w-20 text-left uppercase text-xs pt-1">Vy</div>
            <div className="bg-blue-600 p-3 rounded-lg rounded-tr-none text-white text-sm flex-1">
              "Jasné, žiadny problém! A ty mi na oplátku môžeš pomôcť s tým zaškolením stážistov vo štvrtok."
            </div>
          </div>
          <div className="flex gap-4">
            <div className="font-bold text-green-600 w-20 text-right uppercase text-xs pt-1">Berač</div>
            <div className="bg-slate-100 p-3 rounded-lg rounded-tl-none text-slate-700 text-sm flex-1">
              "Ehm... no... uvidím."
            </div>
          </div>
        </div>
        
        <p className="text-sm text-slate-500 mt-6 italic text-center">
          Urobte to dvakrát a berač pôjde hľadať inú obeť. Neurazíte ho, len mu prestanete byť užitoční zadarmo.
        </p>
      </div>
    </div>
  );

  const renderPsychopath = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-red-700 p-8 rounded-3xl border border-red-900 text-center text-white shadow-2xl">
        <div className="w-20 h-20 bg-red-900 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl shadow-inner border border-red-800">
          <i className="fa-solid fa-skull"></i>
        </div>
        <h2 className="text-3xl font-extrabold text-white mb-2">Psychopati</h2>
        <p className="text-red-200 max-w-2xl mx-auto font-mono uppercase tracking-widest">
          Nebezpečenstvo
        </p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border-l-8 border-red-700">
        <h3 className="font-bold text-xl text-slate-900 mb-4">Biologicky odlišní</h3>
        <p className="text-slate-600 leading-relaxed mb-6">
          Výskumník Robert Hare poslal do časopisu EEG skeny mozgov. Editor ich zamietol s tým, že "nemôžu byť od skutočných ľudí". Boli to mozgy psychopatov. 
          Títo ľudia (cca 1% populácie) nemajú "svedomie" ani empatiu. Sú chladnokrvní, často charizmatickí a bezohľadní. 
          Mnoho z nich nie je vo väzení, ale vo vedení firiem (CEO).
        </p>
        
        <div className="grid md:grid-cols-2 gap-4 mb-6">
           <div className="bg-red-50 p-4 rounded-lg">
             <strong className="block text-red-900 text-sm mb-1">Ako vyzerajú?</strong>
             <ul className="list-disc list-inside text-xs text-red-800 space-y-1">
               <li>Povrchne šarmantní</li>
               <li>Klamú bez mrknutia oka</li>
               <li>Manipulujú pre zábavu alebo zisk</li>
               <li>Nulový súcit</li>
             </ul>
           </div>
           <div className="bg-red-50 p-4 rounded-lg">
             <strong className="block text-red-900 text-sm mb-1">Čo na nich neplatí?</strong>
             <ul className="list-disc list-inside text-xs text-red-800 space-y-1">
               <li>Dojemné príbehy (necítia ich)</li>
               <li>Prosby o zľutovanie</li>
               <li>Logika a dohody</li>
               <li>"Just Listen" techniky</li>
             </ul>
           </div>
        </div>

        <div className="bg-red-600 text-white p-6 rounded-xl text-center shadow-lg transform scale-105">
          <h4 className="text-2xl font-black uppercase mb-2"><i className="fa-solid fa-person-running"></i> Jediná stratégia: UTEKAJTE</h4>
          <p className="font-medium">
            Odíďte. Zmeňte prácu. Prehryznite si nohu, ak musíte, aby ste sa dostali z pasce. 
            Nikdy sa s nimi nesnažte vyjednávať ani ich "zmeniť". Zničia vás finančne aj emocionálne a ani sa neobzru.
          </p>
        </div>
      </div>
    </div>
  );

  // --- MAIN MENU RENDER ---

  if (view === 'MENU') {
    return (
      <div className="container mx-auto px-6 pt-24 pb-12 animate-fade-in max-w-6xl">
        <button 
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors group"
        >
          <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-50">
            <i className="fa-solid fa-arrow-left"></i>
          </div>
          Späť na zoznam pravidiel
        </button>

        <div className="text-center mb-16">
          <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase mb-3 inline-block">Pravidlo #9</span>
          <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Vyhýbajte sa toxickým ľuďom</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            "Toxický človek vás okradne o sebaúctu, dôstojnosť a otrávi podstatu toho, kým ste." <br/>
            <span className="text-sm text-slate-400 mt-2 block">— Lilian Glass</span>
          </p>
          <div className="mt-8 bg-white p-6 rounded-2xl shadow-sm border border-slate-100 max-w-2xl mx-auto">
            <p className="text-slate-700 italic">
              Mark Goulston si po operácii v nemocnici uvedomil, že jeho najväčším stresorom nie je práca, ale toxickí ľudia. Rozhodol sa ich zbaviť. Existujú 3 spôsoby:
              <br /><br />
              <strong>1. Konfrontovať</strong>, <strong>2. Neutralizovať</strong>, <strong>3. Odísť</strong>.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div onClick={() => setView('NEEDY')} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer border-t-8 border-blue-500 group">
            <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-bucket"></i>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Večne Potrební</h3>
            <p className="text-sm text-slate-600 mb-4">Citoví upíri a bezodné jamy.</p>
            <div className="text-xs font-bold text-blue-600 uppercase tracking-wide flex items-center gap-2">
              Spustiť test <i className="fa-solid fa-arrow-right"></i>
            </div>
          </div>

          <div onClick={() => setView('NARCISSIST')} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer border-t-8 border-purple-500 group">
            <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-crown"></i>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Narcisti</h3>
            <p className="text-sm text-slate-600 mb-4">Všetko je len o nich. Vy ste zrkadlo.</p>
            <div className="text-xs font-bold text-purple-600 uppercase tracking-wide flex items-center gap-2">
              Spustiť test <i className="fa-solid fa-arrow-right"></i>
            </div>
          </div>

          <div onClick={() => setView('BULLY')} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer border-t-8 border-slate-700 group">
            <div className="w-14 h-14 bg-slate-100 text-slate-700 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-hand-fist"></i>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Tyrani</h3>
            <p className="text-sm text-slate-600 mb-4">Zastrašovanie a agresia.</p>
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-2">
              Zobraziť stratégiu <i className="fa-solid fa-arrow-right"></i>
            </div>
          </div>

          <div onClick={() => setView('TAKER')} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer border-t-8 border-green-500 group">
            <div className="w-14 h-14 bg-green-100 text-green-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-hand-holding-dollar"></i>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Berači</h3>
            <p className="text-sm text-slate-600 mb-4">Len berú, nikdy nedávajú.</p>
            <div className="text-xs font-bold text-green-600 uppercase tracking-wide flex items-center gap-2">
              Zobraziť stratégiu <i className="fa-solid fa-arrow-right"></i>
            </div>
          </div>

          <div onClick={() => setView('PSYCHOPATH')} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all cursor-pointer border-t-8 border-red-600 group">
            <div className="w-14 h-14 bg-red-100 text-red-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-skull"></i>
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Psychopati</h3>
            <p className="text-sm text-slate-600 mb-4">Bez svedomia. Nebezpeční.</p>
            <div className="text-xs font-bold text-red-600 uppercase tracking-wide flex items-center gap-2">
              VAROVANIE <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- SUBPAGE RENDERER ---

  return (
    <div className="container mx-auto px-6 pt-24 pb-12 max-w-4xl">
      <button 
        onClick={resetToMenu}
        className="mb-8 flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors group"
      >
        <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-50">
          <i className="fa-solid fa-arrow-left"></i>
        </div>
        Späť na výber typov
      </button>

      {view === 'NEEDY' && renderNeedy()}
      {view === 'NARCISSIST' && renderNarcissist()}
      {view === 'BULLY' && renderBully()}
      {view === 'TAKER' && renderTaker()}
      {view === 'PSYCHOPATH' && renderPsychopath()}

    </div>
  );
};