import React, { useState, useEffect } from 'react';
import { Screen, CardProps, SectionProps } from './types';
import { PersuasionCycleView } from './components/PersuasionCycleView';
import { JustListenView } from './components/JustListenView';
import { TrainingModuleView } from './components/TrainingModuleView';
import { AuthorsView } from './components/AuthorsView';
import { SystemsView } from './components/SystemsView';

const NavCard: React.FC<CardProps> = ({ title, description, icon, onClick, colorClass }) => (
  <div 
    onClick={onClick}
    className="bg-white rounded-2xl shadow-md hover:shadow-2xl p-8 cursor-pointer transform transition-all duration-300 hover:-translate-y-2 flex flex-col h-full border border-gray-100 group overflow-hidden relative"
  >
    <div className={`absolute top-0 right-0 w-32 h-32 -mr-10 -mt-10 rounded-full ${colorClass} opacity-10 group-hover:scale-150 transition-transform duration-500`}></div>
    
    <div className={`w-14 h-14 rounded-xl ${colorClass} bg-opacity-10 flex items-center justify-center mb-6 group-hover:rotate-6 transition-transform duration-300`}>
      <i className={`fa-solid ${icon} text-2xl ${colorClass.replace('bg-', 'text-')}`}></i>
    </div>
    
    <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-primary transition-colors">{title}</h3>
    <p className="text-gray-500 flex-grow leading-relaxed text-sm">{description}</p>
    
    <div className={`mt-6 font-semibold text-sm flex items-center ${colorClass.replace('bg-', 'text-')}`}>
      Otvoriť <i className="fa-solid fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
    </div>
  </div>
);

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.HOME);
  const [scrolled, setScrolled] = useState(false);
  const [targetRuleId, setTargetRuleId] = useState<number | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
    setTargetRuleId(null); // Reset rule ID on normal navigation
    scrollToTop();
  };

  const handleNavigateToRule = (ruleId: number) => {
    setTargetRuleId(ruleId);
    setCurrentScreen(Screen.RULES_OVERVIEW);
    scrollToTop();
  };

  const renderContent = () => {
    switch (currentScreen) {
      case Screen.PERSUASION_CYCLE:
        return <PersuasionCycleView onBack={() => navigateTo(Screen.HOME)} onNavigateToRule={handleNavigateToRule} />;
      case Screen.RULES_OVERVIEW:
        return <JustListenView onBack={() => navigateTo(Screen.HOME)} initialRuleId={targetRuleId} />;
      case Screen.SYSTEMS_OVERVIEW:
        return <SystemsView onBack={() => navigateTo(Screen.HOME)} />;
      case Screen.DETAILED_GUIDE:
        return <TrainingModuleView onBack={() => navigateTo(Screen.HOME)} />;
      case Screen.AUTHORS:
        return <AuthorsView onBack={() => navigateTo(Screen.HOME)} />;
      default:
        return (
          <div className="animate-fade-in pb-12">
            {/* Hero Section */}
            <div className="relative bg-gradient-to-br from-slate-900 via-primary to-blue-900 text-white pt-32 pb-40 rounded-b-[4rem] shadow-2xl overflow-hidden mb-12">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
              
              {/* Floating blobs */}
              <div className="absolute top-20 left-10 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
              <div className="absolute bottom-10 right-10 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ animationDelay: '2s' }}></div>

              <div className="container mx-auto px-6 relative z-10 text-center">
                <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-blue-100 text-sm font-medium">
                  <i className="fa-solid fa-brain mr-2"></i> Psychológia & Komunikácia
                </div>
                <h1 className="text-4xl md:text-7xl font-extrabold mb-6 tracking-tight leading-tight">
                  Presviedčací Cyklus
                </h1>
                <p className="text-lg md:text-2xl text-blue-100 max-w-3xl mx-auto font-light leading-relaxed mb-10">
                  „Naučte sa komunikovať s ľudským mozgom, nie proti nemu. <br/>
                  <span className="font-semibold text-white">Preveďte partnera od odporu k nadšenej spolupráci.</span>“
                </p>
              </div>
            </div>

            {/* Content Cards - Centered Grid */}
            <div className="container mx-auto px-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 -mt-24 relative z-20 max-w-6xl mx-auto">
                <NavCard 
                  title="O Presviedčacom Cykle"
                  description="Podstata cyklu, fázy a psychológia za nimi. Syntéza metódy Marka Goulstona."
                  icon="fa-arrows-spin"
                  colorClass="bg-blue-600"
                  onClick={() => navigateTo(Screen.PERSUASION_CYCLE)}
                />
                <NavCard 
                  title="Systém 1 a Systém 2"
                  description="Ako funguje ľudský mozog podľa Daniela Kahnemana. Intuícia (95%) vs. Racionalita (5%)."
                  icon="fa-brain"
                  colorClass="bg-red-500"
                  onClick={() => navigateTo(Screen.SYSTEMS_OVERVIEW)}
                />
                <NavCard 
                  title="9 Pravidiel Komunikácie"
                  description="Kľúčové zásady a praktické techniky 'Just Listen' pre každodenný život."
                  icon="fa-list-check"
                  colorClass="bg-indigo-600"
                  onClick={() => navigateTo(Screen.RULES_OVERVIEW)}
                />
              </div>
            </div>

            {/* Additional Info / Footer */}
            <div className="container mx-auto px-6 mt-20 text-center">
              <div className="border-t border-gray-200 pt-10">
                <h3 className="text-gray-400 uppercase tracking-widest text-sm font-bold mb-8">Zdroje a Inšpirácia</h3>
                <div className="flex justify-center gap-16 opacity-80 mb-12">
                  <div 
                    onClick={() => navigateTo(Screen.AUTHORS)}
                    className="text-center group cursor-pointer hover:scale-105 transition-transform"
                  >
                    <div className="w-16 h-16 mx-auto bg-gray-200 rounded-full flex items-center justify-center mb-3 group-hover:bg-blue-100 transition-colors">
                      <i className="fa-solid fa-brain text-2xl text-gray-400 group-hover:text-blue-600 transition-colors"></i>
                    </div>
                    <p className="text-sm font-bold text-gray-700 group-hover:text-blue-800">Daniel Kahneman</p>
                    <p className="text-[10px] text-gray-500">Thinking, Fast and Slow</p>
                  </div>
                  <div 
                    onClick={() => navigateTo(Screen.AUTHORS)}
                    className="text-center group cursor-pointer hover:scale-105 transition-transform"
                  >
                    <div className="w-16 h-16 mx-auto bg-gray-200 rounded-full flex items-center justify-center mb-3 group-hover:bg-indigo-100 transition-colors">
                      <i className="fa-solid fa-ear-listen text-2xl text-gray-400 group-hover:text-indigo-600 transition-colors"></i>
                    </div>
                    <p className="text-sm font-bold text-gray-700 group-hover:text-indigo-800">Mark Goulston</p>
                    <p className="text-[10px] text-gray-500">Just Listen</p>
                  </div>
                </div>

                <div className="mb-12">
                  <a 
                    href="https://chatgpt.com/g/g-69848b708bb0819188b7ddcde94affbd-presviedcaci-cyklus" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 border border-emerald-500"
                  >
                    <i className="fa-solid fa-robot"></i>
                    Vyskúšať GPT Asistenta: Presviedčací Cyklus
                  </a>
                </div>

                <p className="text-gray-400 text-sm mt-12">© 2026 MindConnect Edukačná Platforma</p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-gray-800 selection:bg-blue-100 selection:text-blue-900">
      {/* Sticky Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-md py-3' : 'bg-transparent py-5'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div 
            className={`text-xl font-extrabold cursor-pointer flex items-center gap-2 transition-colors ${currentScreen === Screen.HOME && !scrolled ? 'text-white' : 'text-primary'}`}
            onClick={() => navigateTo(Screen.HOME)}
          >
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${currentScreen === Screen.HOME && !scrolled ? 'bg-white/20' : 'bg-primary text-white'}`}>
              <i className="fa-solid fa-brain text-sm"></i>
            </div>
            MindConnect
          </div>
          
          {currentScreen !== Screen.HOME && (
            <button 
              onClick={() => navigateTo(Screen.HOME)}
              className="group flex items-center gap-2 px-4 py-2 rounded-full bg-slate-100 hover:bg-primary hover:text-white transition-all text-sm font-medium text-slate-600"
            >
              <i className="fa-solid fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> 
              Späť domov
            </button>
          )}
        </div>
      </nav>

      {renderContent()}
    </div>
  );
};

export default App;