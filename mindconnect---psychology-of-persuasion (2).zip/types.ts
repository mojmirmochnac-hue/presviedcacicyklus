export enum Screen {
  HOME = 'HOME',
  PERSUASION_CYCLE = 'PERSUASION_CYCLE',
  RULES_OVERVIEW = 'RULES_OVERVIEW',
  SYSTEMS_OVERVIEW = 'SYSTEMS_OVERVIEW',
  DETAILED_GUIDE = 'DETAILED_GUIDE',
  AUTHORS = 'AUTHORS'
}

export interface CardProps {
  title: string;
  description: string;
  icon: string;
  onClick: () => void;
  colorClass: string;
}

export interface SectionProps {
  onBack: () => void;
  onNavigateToRule?: (ruleId: number) => void;
  initialRuleId?: number | null;
}